const PLATFORMS_DATA = [
  {
    category: "Mobile & Tablet",
    items: [
      {
        id: "ios-iphone",
        name: "iPhone",
        status: "Coming Soon",
        available: false,
        icon: "phone",
        requirements: "Requires iOS 15.0 or later",
        url: null,
        sync: true
      },
      {
        id: "ios-ipad",
        name: "iPad",
        status: "Coming Soon",
        available: false,
        icon: "tablet",
        requirements: "Requires iPadOS 15.0 or later",
        url: null,
        sync: true
      },
      {
        id: "android-phone",
        name: "Android Phone",
        status: "Coming Soon",
        available: false,
        icon: "phone",
        requirements: "Requires Android 9.0 or later",
        url: null,
        sync: true
      },
      {
        id: "android-tablet",
        name: "Android Tablet",
        status: "Coming Soon",
        available: false,
        icon: "tablet",
        requirements: "Requires Android 9.0 or later",
        url: null,
        sync: true
      }
    ]
  },
  {
    category: "Web & Progressive Web App",
    items: [
      {
        id: "web-pwa",
        name: "Web / PWA",
        status: "Available now",
        available: true,
        icon: "browser",
        requirements: "Chrome, Safari, Firefox, Edge",
        url: "/",
        sync: true
      }
    ]
  },
  {
    category: "Desktop",
    items: [
      {
        id: "mac",
        name: "macOS",
        status: "Desktop release pending",
        available: false,
        icon: "desktop",
        requirements: "Requires macOS 12.0 or later",
        url: null,
        sync: true
      },
      {
        id: "windows",
        name: "Windows",
        status: "Desktop release pending",
        available: false,
        icon: "desktop",
        requirements: "Requires Windows 10 or later",
        url: null,
        sync: true
      },
      {
        id: "linux",
        name: "Linux",
        status: "Desktop release pending",
        available: false,
        icon: "terminal",
        requirements: "AppImage / Debian",
        url: null,
        sync: true
      }
    ]
  }
];

const IconBrowser = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="3" width="20" height="18" rx="2" ry="2"></rect>
    <line x1="2" y1="9" x2="22" y2="9"></line>
  </svg>
);
const IconPhone = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect>
    <line x1="12" y1="18" x2="12.01" y2="18"></line>
  </svg>
);
const IconTablet = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <rect x="4" y="2" width="16" height="20" rx="2" ry="2"></rect>
    <line x1="12" y1="18" x2="12.01" y2="18"></line>
  </svg>
);
const IconDesktop = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
    <line x1="8" y1="21" x2="16" y2="21"></line>
    <line x1="12" y1="17" x2="12" y2="21"></line>
  </svg>
);
const IconTerminal = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="4 17 10 11 4 5"></polyline>
    <line x1="12" y1="19" x2="20" y2="19"></line>
  </svg>
);

const getPlatformIcon = (iconName) => {
  switch (iconName) {
    case "browser": return <IconBrowser />;
    case "phone": return <IconPhone />;
    case "tablet": return <IconTablet />;
    case "desktop": return <IconDesktop />;
    case "terminal": return <IconTerminal />;
    default: return <IconBrowser />;
  }
};

function PlatformsPage() {
  const [installPrompt,setInstallPrompt]=useState(null);
  const [installMessage,setInstallMessage]=useState("");
  useEffect(()=>{
    const capture=event=>{event.preventDefault();setInstallPrompt(event);};
    const installed=()=>{setInstallPrompt(null);setInstallMessage("Installed. You can now open The Dhikr Challenge from your device.");};
    window.addEventListener("beforeinstallprompt",capture);
    window.addEventListener("appinstalled",installed);
    return()=>{window.removeEventListener("beforeinstallprompt",capture);window.removeEventListener("appinstalled",installed);};
  },[]);
  const handleInstall = async () => {
    if(installPrompt){
      await installPrompt.prompt();
      const choice=await installPrompt.userChoice;
      if(choice.outcome==="accepted")setInstallPrompt(null);
      return;
    }
    setInstallMessage("On iPhone or iPad, use Safari’s Share menu and choose Add to Home Screen. On desktop or Android, use your browser’s Install option.");
  };

  return (
    <div className="platforms-page">
      <div className="anim-up platforms-header">
        <div style={{fontSize:11,color:"var(--amber)",fontFamily:"var(--font)",fontWeight:600,textTransform:"uppercase",letterSpacing:".12em",marginBottom:8}}>Where to Practice</div>
        <div className="platforms-title">Platforms & Apps</div>
        <div className="platforms-desc">
          The Dhikr Challenge is designed to be with you wherever you need a quiet moment of return. 
          Your practice, reflections, and circles sync seamlessly across all your devices with full audio parity.
        </div>
       {installMessage&&<div className="platform-install-note" role="status">{installMessage}</div>}
      </div>

      <div className="anim-up platforms-content">
        {PLATFORMS_DATA.map((section) => (
          <div key={section.category} className="platform-section">
            <div className="platform-section-title">{section.category}</div>
            <div className="platform-grid">
              {section.items.map((platform) => (
                <div key={platform.id} className={`platform-card ${platform.available ? 'active' : 'pending'}`}>
                  {platform.available && (
                    <div className="platform-badge">Active</div>
                  )}
                  
                  <div className="platform-card-header">
                    <div className="platform-icon-container">
                      {getPlatformIcon(platform.icon)}
                    </div>
                    <div>
                      <div className="platform-name">{platform.name}</div>
                      <div className="platform-status">
                        {platform.status}
                      </div>
                    </div>
                  </div>

                  <div className="platform-details">
                    <div className="platform-detail-item">
                      <span className="platform-detail-bullet">•</span>
                      <span>{platform.requirements}</span>
                    </div>
                    <div className="platform-detail-item">
                      <span className="platform-detail-bullet">•</span>
                      <span>Full privacy & account sync</span>
                    </div>
                  </div>

                  {platform.available ? (
                    <button onClick={handleInstall} className="platform-btn active">
                      Install / Open
                    </button>
                  ) : (
                    <button disabled className="platform-btn pending">
                      Not yet available
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
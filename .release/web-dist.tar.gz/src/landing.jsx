function LandingPage({ onAuthChange }) {
  const platforms = PLATFORMS_DATA.flatMap(section => section.items);

  return (
    <div style={{ height: "100%", overflowY: "auto", padding: "0 20px 80px", maxWidth: 600, margin: "0 auto", position: "relative" }}>
      <div style={{ position: "absolute", top: "-10%", left: "50%", transform: "translateX(-50%)", width: "120%", height: 400, background: "radial-gradient(ellipse,rgba(217,174,88,0.06),transparent 60%)", pointerEvents: "none", zIndex: 0 }} />
      
      <header className="anim-up" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "24px 0 40px", position: "relative", zIndex: 1 }}>
        <div style={{ fontFamily: "var(--arabic)", fontSize: 16, color: "var(--amber)", direction: "rtl" }}>بِسْمِ ٱللَّهِ</div>
        <button onClick={() => onAuthChange("signin")} style={{ background: "transparent", border: "1px solid var(--border2)", borderRadius: 10, padding: "8px 14px", color: "var(--text)", fontSize: 12, fontWeight: 600 }}>Sign in</button>
      </header>

      <div className="anim-up d1" style={{ textAlign: "center", marginBottom: 48, position: "relative", zIndex: 1 }}>
        <div style={{ display: "flex", justifyContent: "center", marginBottom: 20 }}>
          <div style={{ width: 64, height: 64, borderRadius: "50%", background: "var(--surface)", border: "1px solid var(--amber-mid)", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--amber2)", fontSize: 24 }}>✦</div>
        </div>
        <h1 style={{ fontFamily: "var(--serif)", fontSize: 38, fontWeight: 400, letterSpacing: "-0.02em", margin: "0 0 16px", lineHeight: 1.1 }}>A quiet return to<br />remembrance.</h1>
        <p style={{ fontSize: 15, color: "var(--text2)", lineHeight: 1.6, maxWidth: 420, margin: "0 auto 28px" }}>
          The Dhikr Challenge is a private daily practice. No streaks, no leaderboards, no pressure. Just a steady, source-aware companion for your heart.
        </p>
        <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
          <button onClick={() => onAuthChange("signup")} style={{ padding: "14px 24px", borderRadius: 12, border: "none", background: "var(--amber)", color: "var(--bg)", fontSize: 14, fontWeight: 600, minWidth: 160 }}>Create account</button>
          <a href="/platforms" style={{ padding: "14px 24px", borderRadius: 12, border: "1px solid var(--border2)", background: "var(--surface)", color: "var(--text)", fontSize: 14, fontWeight: 600, minWidth: 160, textDecoration: "none" }}>See platforms</a>
        </div>
      </div>

      <div className="anim-up d2" style={{ display: "grid", gap: 16, marginBottom: 48, position: "relative", zIndex: 1 }}>
        <div style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 16, padding: 24 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: "var(--green-dim)", color: "var(--green2)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 16, fontSize: 16 }}>◎</div>
          <h3 style={{ fontSize: 16, fontWeight: 500, marginBottom: 8, color: "var(--text)" }}>Human-recorded recitation</h3>
          <p style={{ fontSize: 14, color: "var(--text3)", lineHeight: 1.6 }}>Learn the pronunciations with clear, human-recorded Arabic audio. Choose to listen to just the Arabic, or include the English meaning.</p>
        </div>
        
        <div style={{ background: "linear-gradient(135deg,var(--surface),var(--bg2))", border: "1px solid var(--border)", borderRadius: 16, padding: 24 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: "var(--amber-dim)", color: "var(--amber2)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 16, fontSize: 16 }}>§</div>
          <h3 style={{ fontSize: 16, fontWeight: 500, marginBottom: 8, color: "var(--text)" }}>Source-aware learning</h3>
          <p style={{ fontSize: 14, color: "var(--text3)", lineHeight: 1.6 }}>Every dhikr and hadith includes its reference (Bukhari, Muslim, Tirmidhi). We encourage learning from qualified scholars for personal rulings.</p>
        </div>
        
        <div style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 16, padding: 24 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: "rgba(184,204,230,0.1)", color: "var(--text2)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 16, fontSize: 16 }}>⚬</div>
          <h3 style={{ fontSize: 16, fontWeight: 500, marginBottom: 8, color: "var(--text)" }}>Private reflections & circles</h3>
          <p style={{ fontSize: 14, color: "var(--text3)", lineHeight: 1.6 }}>Keep a private journal of your daily return. Invite friends or family to a circle for gentle encouragement without sharing counts or streaks.</p>
        </div>
      </div>

      <div className="anim-up d3" style={{ background: "var(--bg2)", border: "1px solid var(--border)", borderRadius: 16, padding: 24, marginBottom: 48, textAlign: "center", position: "relative", zIndex: 1 }}>
        <h3 style={{ fontSize: 16, fontWeight: 500, marginBottom: 16, color: "var(--text)" }}>Available Platforms</h3>
        <div className="landing-platform-list">
          {platforms.map(platform => (
            <div className={`landing-platform-item ${platform.available ? "available" : ""}`} key={platform.id}>
              <strong>{platform.name}</strong>
              <span>{platform.status}</span>
            </div>
          ))}
        </div>
        <a href="/platforms" style={{ display: "inline-block", background: "transparent", border: "1px solid var(--border2)", borderRadius: 8, padding: "8px 12px", color: "var(--text2)", fontSize: 12, textDecoration: "none" }}>View platform details</a>
      </div>

      <footer className="anim-up d4" style={{ textAlign: "center", borderTop: "1px solid var(--border)", paddingTop: 32, paddingBottom: 16, position: "relative", zIndex: 1 }}>
        <h2 style={{ fontFamily: "var(--serif)", fontSize: 28, marginBottom: 20, color: "var(--text)" }}>Begin your practice.</h2>
        <button onClick={() => onAuthChange("signup")} style={{ padding: "14px 32px", borderRadius: 12, border: "none", background: "var(--amber)", color: "var(--bg)", fontSize: 15, fontWeight: 600, marginBottom: 24 }}>Create your account</button>
        <div style={{ fontSize: 11, color: "var(--text3)", lineHeight: 1.6, maxWidth: 300, margin: "0 auto" }}>
          Your practice, reflections, and circle participation are designed to remain private to your account.
        </div>
      </footer>
    </div>
  );
}

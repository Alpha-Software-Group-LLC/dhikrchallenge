---
name: Supabase development bridge
description: How the Replit preview reaches the existing Supabase project without changing production behavior.
---

When the Vercel-style public Supabase configuration variables are absent in development, use the installed Replit Supabase connector as a same-origin bridge. Production continues to serve its public URL and publishable key directly.

**Why:** The connector is attached to the workspace but does not export the browser configuration variables used by the existing Vercel app. The bridge keeps the preview functional without storing or exposing credentials.

**How to apply:** Preserve this as a development-only fallback. Do not route Vercel production through the connector or replace the app's existing Supabase authentication and RLS model.
---
name: Tauri builds on Replit
description: Replit/Nix-specific native linking behavior for local Tauri release verification.
---

On Replit, a Tauri debug check can pass while an optimized build fails to link `-lz`. For local verification, expose the directory reported by `pkg-config --variable=libdir zlib` through `LIBRARY_PATH`.

**Why:** Nix can make zlib visible to `pkg-config` without adding its runtime library directory to the release linker's default search path.

**How to apply:** Use this only for local Replit release-build verification. Native GitHub runners install their platform prerequisites normally and should not inherit this workaround.
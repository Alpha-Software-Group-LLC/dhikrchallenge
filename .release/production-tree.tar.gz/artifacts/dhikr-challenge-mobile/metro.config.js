const { getDefaultConfig } = require('expo/metro-config');
const path = require('path');

const config = getDefaultConfig(__dirname);
const tauriTarget = path.resolve(__dirname, '../dhikr-challenge-web/src-tauri/target');
const escapedTarget = tauriTarget.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

config.resolver.blockList = new RegExp(`${escapedTarget}[/\\\\].*`);

module.exports = config;

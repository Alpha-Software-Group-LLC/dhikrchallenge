import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { useAudioPlayer, useAudioPlayerStatus } from 'expo-audio';
import { Feather } from '@expo/vector-icons';
import { ARABIC_AUDIO } from '@/lib/data';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Speech from 'expo-speech';

interface RecitationControlsProps {
  dhikrId: string;
  meaning: string;
  compact?: boolean;
}

export function RecitationControls({ dhikrId, meaning, compact = false }: RecitationControlsProps) {
  const colors = useColors();
  const [mode, setMode] = useState('arabic');
  const [speechPlaying, setSpeechPlaying] = useState(false);
  
  useEffect(() => {
    AsyncStorage.getItem('dhikr-recitation-mode').then(val => {
      if (val) setMode(val);
    });
  }, []);

  const source = ARABIC_AUDIO[dhikrId];
  const player = useAudioPlayer(source);
  const status = useAudioPlayerStatus(player);

  const playing = status.playing || speechPlaying;

  const togglePlay = () => {
    if (playing) {
      if (status.playing) player.pause();
      if (speechPlaying) {
        Speech.stop();
        setSpeechPlaying(false);
      }
    } else {
      if (mode === 'english') {
        setSpeechPlaying(true);
        Speech.speak(meaning, {
          onDone: () => setSpeechPlaying(false),
          onStopped: () => setSpeechPlaying(false),
          onError: () => setSpeechPlaying(false),
        });
      } else if (mode === 'both') {
        if (status.currentTime > 0 && status.currentTime >= status.duration) {
          player.seekTo(0);
        }
        player.play();
        setTimeout(() => {
          setSpeechPlaying(true);
          Speech.speak(meaning, {
            onDone: () => setSpeechPlaying(false),
            onStopped: () => setSpeechPlaying(false),
            onError: () => setSpeechPlaying(false),
          });
        }, 1500);
      } else {
        if (status.currentTime > 0 && status.currentTime >= status.duration) {
          player.seekTo(0);
        }
        player.play();
      }
    }
  };

  useEffect(() => {
    return () => {
      Speech.stop();
    };
  }, []);

  return (
    <View style={styles.container}>
      <TouchableOpacity 
        style={[styles.playButton, { backgroundColor: colors.amberDim, borderColor: colors.amberMid, paddingVertical: compact ? 6 : 8 }]}
        onPress={togglePlay}
      >
        <Feather name={playing ? "square" : "play"} size={14} color={colors.amber2} />
        <Text style={[styles.playText, { color: colors.amber2 }]}>{playing ? "Stop" : "Play"}</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  playButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
    borderWidth: 1,
  },
  playText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 12,
  }
});

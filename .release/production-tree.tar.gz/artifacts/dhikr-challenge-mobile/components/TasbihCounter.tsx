import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Modal, Dimensions } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { Dhikr } from '@/lib/data';
import * as Haptics from 'expo-haptics';
import Animated, { useAnimatedStyle, withSpring, withSequence, withTiming, runOnJS } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';

interface TasbihCounterProps {
  dhikr: Dhikr;
  visible: boolean;
  onClose: () => void;
  onComplete: (dhikr: Dhikr) => void;
}

const { width } = Dimensions.get('window');
const CIRCLE_SIZE = Math.min(width * 0.7, 280);

export function TasbihCounter({ dhikr, visible, onClose, onComplete }: TasbihCounterProps) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [count, setCount] = useState(0);
  const [completed, setCompleted] = useState(false);

  useEffect(() => {
    if (visible) {
      setCount(0);
      setCompleted(false);
    }
  }, [visible, dhikr]);

  const handleTap = () => {
    if (completed) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const next = count + 1;
    setCount(next);

    if (next >= dhikr.target) {
      setCompleted(true);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setTimeout(() => {
        onComplete(dhikr);
      }, 1500);
    }
  };

  const progress = Math.min(count / dhikr.target, 1);

  if (!visible) return null;

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="formSheet">
      <View style={[styles.container, { backgroundColor: colors.background, paddingTop: Math.max(insets.top, 20), paddingBottom: insets.bottom }]}>
        <View style={styles.header}>
          <TouchableOpacity onPress={onClose} style={[styles.backButton, { backgroundColor: colors.surface, borderColor: colors.border2 }]}>
            <Feather name="arrow-left" size={16} color={colors.text2} />
            <Text style={[styles.backText, { color: colors.text2 }]}>BACK</Text>
          </TouchableOpacity>
          <Text style={[styles.category, { color: colors.text3 }]}>{dhikr.category}</Text>
        </View>

        <View style={styles.content}>
          <Text style={[styles.arabic, { color: colors.green2, textShadowColor: colors.greenDim, textShadowRadius: 10 }]}>{dhikr.arabic}</Text>
          <Text style={[styles.transliteration, { color: colors.text2 }]}>{dhikr.transliteration}</Text>
          <Text style={[styles.meaning, { color: colors.text3 }]}>{dhikr.meaning}</Text>

          <View style={styles.counterWrapper}>
            <TouchableOpacity 
              activeOpacity={0.9} 
              onPress={handleTap} 
              style={[
                styles.tapTarget, 
                { 
                  width: CIRCLE_SIZE, 
                  height: CIRCLE_SIZE, 
                  borderRadius: CIRCLE_SIZE / 2,
                  backgroundColor: colors.surface,
                  shadowColor: completed ? colors.green : colors.shadow,
                  shadowOpacity: completed ? 0.4 : 0.15,
                  shadowRadius: completed ? 20 : 15,
                  shadowOffset: { width: 0, height: 8 },
                  elevation: 10,
                }
              ]}
            >
              <View style={[styles.progressRing, { 
                borderRadius: CIRCLE_SIZE / 2, 
                borderColor: colors.border2, 
                borderWidth: 2 
              }]}>
              </View>

              {!completed ? (
                <View style={styles.countInfo}>
                  <Text style={[styles.countNumber, { color: colors.green2 }]}>{count}</Text>
                  <Text style={[styles.countTarget, { color: colors.text3 }]}>/ {dhikr.target}</Text>
                </View>
              ) : (
                <View style={styles.completedInfo}>
                  <Feather name="check" size={40} color={colors.amber2} />
                  <Text style={[styles.completedText, { color: colors.amber2 }]}>Completed</Text>
                </View>
              )}
            </TouchableOpacity>
          </View>

          <Text style={[styles.instruction, { color: colors.text3 }]}>
            {completed ? "MashaAllah! May Allah accept it." : "Tap the circle to count"}
          </Text>
          {!completed && (
            <Text style={[styles.meditation, { color: colors.text2 }]}>
              Take a breath. Let the meaning arrive before the number.
            </Text>
          )}
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
  },
  backText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 11,
    letterSpacing: 0.5,
  },
  category: {
    fontFamily: 'Inter_500Medium',
    fontSize: 12,
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
  },
  arabic: {
    fontFamily: 'Inter_400Regular', // fallback for arabic
    fontSize: 36,
    textAlign: 'center',
    marginBottom: 12,
    lineHeight: 48,
  },
  transliteration: {
    fontFamily: 'Inter_500Medium',
    fontSize: 15,
    marginBottom: 6,
    textAlign: 'center',
    letterSpacing: 0.5,
  },
  meaning: {
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
    marginBottom: 40,
    textAlign: 'center',
  },
  counterWrapper: {
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 40,
  },
  tapTarget: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  progressRing: {
    position: 'absolute',
    top: 0, left: 0, right: 0, bottom: 0,
  },
  countInfo: {
    alignItems: 'center',
  },
  countNumber: {
    fontFamily: 'Inter_400Regular',
    fontSize: 64,
    lineHeight: 72,
  },
  countTarget: {
    fontFamily: 'Inter_500Medium',
    fontSize: 14,
    marginTop: 4,
  },
  completedInfo: {
    alignItems: 'center',
  },
  completedText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 16,
    marginTop: 8,
  },
  instruction: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 12,
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 12,
  },
  meditation: {
    fontFamily: 'Inter_400Regular',
    fontStyle: 'italic',
    fontSize: 13,
    textAlign: 'center',
    maxWidth: 240,
    lineHeight: 20,
  }
});

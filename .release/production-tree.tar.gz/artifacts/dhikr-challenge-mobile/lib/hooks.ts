import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getSupabase } from './supabase';
import { useAuth } from '@/context/AuthContext';
import { todayStr, dateNDaysAgo } from './data';

// --- Progress ---
export function useMyProgress() {
  const { user } = useAuth();
  return useQuery({
    queryKey: ['my_dhikr_progress', user?.id],
    queryFn: async () => {
      const supabase = await getSupabase();
      const { data, error } = await supabase.rpc('my_dhikr_progress');
      if (error) throw error;
      
      const freshData = {
        streak: 0,
        lastActiveDate: null,
        completedToday: [],
        totalCompletions: 0,
        xp: 0,
        history: [],
      };
      const next = { ...freshData, ...(data || {}) };
      
      let cursor = todayStr();
      let streak = 0;
      const activeDays = new Set(next.history.map((h: any) => h.date));
      if (!activeDays.has(cursor)) cursor = dateNDaysAgo(1);
      
      while (activeDays.has(cursor)) {
        streak += 1;
        const d = new Date(cursor + "T00:00:00Z");
        d.setUTCDate(d.getUTCDate() - 1);
        cursor = d.toISOString().slice(0, 10);
      }
      
      return { ...next, streak };
    },
    enabled: !!user,
  });
}

export function useCompleteDhikr() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  
  return useMutation({
    mutationFn: async (dhikrId: string) => {
      const supabase = await getSupabase();
      const { data, error } = await supabase.rpc('complete_daily_dhikr', { p_dhikr_id: dhikrId });
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my_dhikr_progress', user?.id] });
      queryClient.invalidateQueries({ queryKey: ['my_dhikr_experience', user?.id] });
    }
  });
}

// --- Experience & Settings ---
export function useMyExperience() {
  const { user } = useAuth();
  return useQuery({
    queryKey: ['my_dhikr_experience', user?.id],
    queryFn: async () => {
      const supabase = await getSupabase();
      const { data, error } = await supabase.rpc('my_dhikr_experience');
      if (error) throw error;
      return data || { onboardingCompleted: true, preferences: { goals: [], duration: 3, audio: "arabic", reminder: "", school: "" }, reflections: [], savedItems: [] };
    },
    enabled: !!user,
  });
}

export function useSavePreferences() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  return useMutation({
    mutationFn: async (prefs: any) => {
      const supabase = await getSupabase();
      const { error } = await supabase.rpc('save_dhikr_preferences', { p_preferences: prefs });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my_dhikr_experience', user?.id] });
    }
  });
}

export function useSaveReflection() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  return useMutation({
    mutationFn: async ({ id, mood, note }: { id: string, mood: string, note: string }) => {
      const supabase = await getSupabase();
      const { error } = await supabase.rpc('save_dhikr_reflection', { p_dhikr_id: id, p_mood: mood, p_note: note });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my_dhikr_experience', user?.id] });
    }
  });
}

export function useToggleSaved() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  return useMutation({
    mutationFn: async ({ type, id }: { type: string, id: string }) => {
      const supabase = await getSupabase();
      const { error } = await supabase.rpc('toggle_saved_item', { p_item_type: type, p_item_id: id });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my_dhikr_experience', user?.id] });
    }
  });
}

// --- Circles ---
export function useMyCircles() {
  const { user } = useAuth();
  return useQuery({
    queryKey: ['my_dhikr_circles', user?.id],
    queryFn: async () => {
      const supabase = await getSupabase();
      const { data, error } = await supabase.rpc('my_dhikr_circles');
      if (error) throw error;
      return Array.isArray(data) ? data : [];
    },
    enabled: !!user,
  });
}

export function useCircleToday(circleId: string | null) {
  const { user } = useAuth();
  return useQuery({
    queryKey: ['circle_today', circleId, user?.id],
    queryFn: async () => {
      if (!circleId) return null;
      const supabase = await getSupabase();
      const { data, error } = await supabase.rpc('circle_today', { p_circle_id: circleId });
      if (error) throw error;
      return data;
    },
    enabled: !!user && !!circleId,
  });
}

export function useCreateCircle() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  return useMutation({
    mutationFn: async (name: string) => {
      const supabase = await getSupabase();
      const { data, error } = await supabase.rpc('create_dhikr_circle', { p_name: name });
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my_dhikr_circles', user?.id] });
    }
  });
}

export function useJoinCircle() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  return useMutation({
    mutationFn: async (code: string) => {
      const supabase = await getSupabase();
      const { data, error } = await supabase.rpc('join_dhikr_circle', { p_invite_code: code });
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my_dhikr_circles', user?.id] });
    }
  });
}

export function useSetCircleIntention() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, intention }: { id: string, intention: string }) => {
      const supabase = await getSupabase();
      const { error } = await supabase.rpc('set_circle_intention', { p_circle_id: id, p_intention: intention });
      if (error) throw error;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['circle_today', variables.id] });
    }
  });
}

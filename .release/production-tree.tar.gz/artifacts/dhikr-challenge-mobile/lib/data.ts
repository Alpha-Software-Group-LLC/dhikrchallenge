export type Dhikr = {
  id: string;
  arabic: string;
  transliteration: string;
  meaning: string;
  target: number;
  xp: number;
  category: string;
  significance: string;
  practiceReflection: string;
  difficulty: string;
  icon: string;
  source: string;
  moment: string;
  reflection: string;
  unit?: string;
  words?: string[][];
};

export const ADHKAR: Dhikr[] = [
  {
    id: "astaghfirullah",
    arabic: "أَسْتَغْفِرُ ٱللَّهَ",
    transliteration: "Astaghfirullah",
    meaning: "I seek forgiveness from Allah",
    target: 30,
    xp: 60,
    category: "Repentance",
    significance: "The Prophet ﷺ said: 'By Allah, I seek forgiveness from Allah and turn to Him in repentance more than seventy times a day.' (Bukhari). Istighfar purifies the heart, removes anxiety, opens doors of mercy, and brings relief from every difficulty.",
    practiceReflection: "Repentance begins with telling the truth about our need for Allah; let the words be accompanied by a sincere turn back.",
    difficulty: "easy",
    icon: "",
    source: "Sahih al-Bukhari 6307",
    moment: "A gentle return after a mistake or a heavy moment.",
    reflection: "What would it feel like to place this burden down before Allah?",
    words: [["أَسْتَغْفِرُ", "astaghfiru", "I seek forgiveness"], ["ٱللَّهَ", "Allaha", "Allah"]]
  },
  {
    id: "la_ilaha_illallah",
    arabic: "لَا إِلَٰهَ إِلَّا ٱللَّهُ",
    transliteration: "La ilaha illallah",
    meaning: "There is no god but Allah",
    target: 10,
    xp: 50,
    category: "Tawheed",
    significance: "The best dhikr is La ilaha illallah (Tirmidhi). This is the declaration of Tawheed — the foundation of Islam and the heaviest statement on the scales on the Day of Judgment.",
    practiceReflection: "Let this declaration shape what you rely on, love, and fear today.",
    difficulty: "easy",
    icon: "",
    source: "Jami' at-Tirmidhi 3383",
    moment: "Whenever you want to renew your center and intention.",
    reflection: "What would change if your heart had one true anchor today?",
    words: [["لَا", "la", "no / there is not"], ["إِلَٰهَ", "ilaha", "god"], ["إِلَّا", "illa", "except"], ["ٱللَّهُ", "Allahu", "Allah"]]
  },
  {
    id: "subhanallah",
    arabic: "سُبْحَانَ ٱللَّهِ",
    transliteration: "SubhanAllah",
    meaning: "Glory be to Allah",
    target: 33,
    xp: 65,
    category: "Glorification",
    significance: "SubhanAllah fills the scales of good deeds. The Prophet ﷺ said: 'Two words that are light on the tongue, heavy on the scales, and beloved to the Most Merciful: SubhanAllahi wa bihamdihi, SubhanAllahil Azeem.' (Bukhari & Muslim)",
    practiceReflection: "Let glorifying Allah interrupt the assumption that you see the whole picture.",
    difficulty: "easy",
    icon: "",
    source: "Sahih al-Bukhari 6682; Sahih Muslim 2694",
    moment: "A quiet reset while walking, waiting, or finishing a task.",
    reflection: "Notice one sign of Allah's perfection around you.",
    words: [["سُبْحَانَ", "subhana", "Glory be"], ["ٱللَّهِ", "Allahi", "of Allah"]]
  },
  {
    id: "alhamdulillah",
    arabic: "ٱلْحَمْدُ لِلَّهِ",
    transliteration: "Alhamdulillah",
    meaning: "All praise is due to Allah",
    target: 33,
    xp: 65,
    category: "Gratitude",
    significance: "Alhamdulillah fills the space between the heavens and the earth (Muslim). Gratitude (shukr) is one of the highest stations of the soul — it transforms perspective and brings increase in blessings.",
    practiceReflection: "Name one blessing without rushing past it; praise can become a way of noticing.",
    difficulty: "easy",
    icon: "",
    source: "Sahih Muslim 223",
    moment: "After receiving a blessing, small or immense.",
    reflection: "Name one blessing you received today without earning it.",
    words: [["ٱلْحَمْدُ", "al-hamdu", "all praise"], ["لِلَّهِ", "lillahi", "belongs to Allah"]]
  },
  {
    id: "allahu_akbar",
    arabic: "ٱللَّهُ أَكْبَرُ",
    transliteration: "Allahu Akbar",
    meaning: "Allah is the Greatest",
    target: 33,
    xp: 65,
    category: "Magnification",
    significance: "Completing SubhanAllah 33×, Alhamdulillah 33×, and Allahu Akbar 33× after every salah is a sunnah that the Prophet ﷺ taught to the Companions when they asked for the best deeds.",
    practiceReflection: "Let “Allahu Akbar” put today's worries in their proper size, without denying the work still before you.",
    difficulty: "easy",
    icon: "",
    source: "Sunan Abi Dawud 150",
    moment: "After salah or when fear makes the world feel too large.",
    reflection: "What worry becomes smaller when Allah is remembered as greater?",
    words: [["ٱللَّهُ", "Allahu", "Allah"], ["أَكْبَرُ", "akbar", "is the Greatest"]]
  },
  {
    id: "quran_reading",
    arabic: "تِلَاوَةُ الْقُرْآنِ",
    transliteration: "Tilawat al-Qur'an",
    meaning: "Recitation of the Qur'an",
    target: 5,
    xp: 100,
    category: "Qur'an",
    significance: "The Prophet ﷺ taught that whoever recites a letter from the Book of Allah receives a multiplied reward, and he said: 'The best of you are those who learn the Qur'an and teach it.' Regular recitation is an act of closeness, learning, and reflection.",
    practiceReflection: "Approach Qur'an recitation with attention, humility, and a willingness to learn.",
    difficulty: "medium",
    icon: "",
    unit: "ayahs",
    source: "Jami' at-Tirmidhi 2910; Sahih al-Bukhari 5027",
    moment: "In a focused window when you can read with presence.",
    reflection: "Take one meaning from the passage into the rest of your day.",
    words: [["تِلَاوَةُ", "tilawatu", "recitation"], ["الْقُرْآنِ", "al-Qur'ani", "of the Qur'an"]]
  },
  {
    id: "salawat",
    arabic: "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ",
    transliteration: "Allahumma salli 'ala Muhammad",
    meaning: "O Allah, send blessings upon Muhammad ﷺ",
    target: 20,
    xp: 70,
    category: "Salawat",
    significance: "Whoever sends one salawat upon me, Allah sends ten blessings upon him (Muslim). Friday is especially virtuous for abundant salawat upon the Prophet ﷺ.",
    practiceReflection: "Let love for the Prophet ﷺ show up as gratitude, good character, and following his guidance.",
    difficulty: "easy",
    icon: "",
    source: "Sahih Muslim 408",
    moment: "Especially on Friday, and whenever love for the Prophet ﷺ rises.",
    reflection: "Let gratitude for the Prophet ﷺ soften one interaction today.",
    words: [["اللَّهُمَّ", "Allahumma", "O Allah"], ["صَلِّ", "salli", "send blessings"], ["عَلَى", "'ala", "upon"], ["مُحَمَّدٍ", "Muhammad", "Muhammad"]]
  },
  {
    id: "hawqala",
    arabic: "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِٱللَّهِ",
    transliteration: "La hawla wa la quwwata illa billah",
    meaning: "There is no power nor strength except with Allah",
    target: 10,
    xp: 55,
    category: "Tawakkul",
    significance: "The Prophet ﷺ called this phrase a 'treasure from the treasures of Paradise' (Bukhari & Muslim). It is the ultimate expression of reliance upon Allah in every matter.",
    practiceReflection: "Say this while taking the next responsible step, then release what is outside your control.",
    difficulty: "easy",
    icon: "",
    source: "Sahih al-Bukhari 6409; Sahih Muslim 2704",
    moment: "When effort feels beyond you and you need to rely on Allah.",
    reflection: "What can you release after doing the next right thing?",
    words: [["لَا", "la", "no"], ["حَوْلَ", "hawla", "power / change"], ["وَلَا", "wa la", "and no"], ["قُوَّةَ", "quwwata", "strength"], ["إِلَّا", "illa", "except"], ["بِٱللَّهِ", "billahi", "through Allah"]]
  }
];

export const HADITHS = [
  {
    id: "return",
    title: "Return often",
    theme: "Repentance",
    text: "The Prophet ﷺ said that he seeks Allah’s forgiveness and turns to Him in repentance more than seventy times each day.",
    reference: "Sahih al-Bukhari 6307",
  },
  {
    id: "light",
    title: "Light on the tongue",
    theme: "Glorification",
    text: "Two words are light on the tongue, heavy on the scale, and beloved to the Most Merciful: SubhanAllahi wa bihamdihi, SubhanAllahil Azeem.",
    reference: "Sahih al-Bukhari 6682; Sahih Muslim 2694",
  },
  {
    id: "praise",
    title: "Praise fills the scale",
    theme: "Gratitude",
    text: "The Prophet ﷺ taught that Alhamdulillah fills the scale, inviting us to notice praise as an act of worship.",
    reference: "Sahih Muslim 223",
  },
  {
    id: "salawat",
    title: "Send one blessing",
    theme: "Salawat",
    text: "Whoever sends one blessing upon the Prophet ﷺ, Allah sends ten blessings upon him.",
    reference: "Sahih Muslim 408",
  },
  {
    id: "treasure",
    title: "A treasure from Paradise",
    theme: "Reliance",
    text: "The Prophet ﷺ described La hawla wa la quwwata illa billah as a treasure from the treasures of Paradise.",
    reference: "Sahih al-Bukhari 6409; Sahih Muslim 2704",
  }
];

export const QURAN_REFERENCES = [
  {
    id: "ease",
    theme: "hardship, patience, hope",
    reference: "Qur’an 94:5–6",
    meaning: "With hardship comes ease; the reminder is repeated as comfort, not as a promise that difficulty is imaginary.",
  },
  {
    id: "remembrance",
    theme: "peace, anxiety, dhikr, heart",
    reference: "Qur’an 13:28",
    meaning: "Hearts find rest in the remembrance of Allah.",
  },
  {
    id: "mercy",
    theme: "sin, repentance, despair, forgiveness",
    reference: "Qur’an 39:53",
    meaning: "Do not despair of Allah’s mercy; the verse calls those who have wronged themselves back toward repentance.",
  },
  {
    id: "remember",
    theme: "dhikr, gratitude, closeness",
    reference: "Qur’an 2:152",
    meaning: "Remember Allah and He will remember you; be grateful and do not deny His blessings.",
  },
  {
    id: "burden",
    theme: "stress, responsibility, hardship, capacity",
    reference: "Qur’an 2:286",
    meaning: "Allah does not burden a soul beyond its capacity; the verse closes with a prayer for help, forgiveness, and mercy.",
  },
  {
    id: "reliance",
    theme: "decision, effort, tawakkul, trust",
    reference: "Qur’an 3:159",
    meaning: "Consult, decide, and then place your reliance upon Allah.",
  }
];

export const QURAN_READING_PATHS = [
  {
    title: "When the heart feels crowded",
    description: "A three-passage path through remembrance, capacity, and ease.",
    items: ["remembrance", "burden", "ease"],
  },
  {
    title: "A return after mistakes",
    description: "Read mercy first, then remembrance and reliance.",
    items: ["mercy", "remember", "reliance"],
  },
  {
    title: "Gratitude with steadiness",
    description: "A short path from remembering to trusting the next step.",
    items: ["remember", "remembrance", "reliance"],
  }
];

export const SEARCH_TOPIC_ALIASES: Record<string, string[]> = {
  anxiety: ["anxiety", "worry", "stress", "overwhelmed", "sad", "fear", "calm", "peace"],
  repentance: ["repent", "sin", "forgive", "forgiveness", "mistake", "guilt", "astaghfirullah"],
  gratitude: ["grateful", "gratitude", "blessing", "thank", "alhamdulillah", "praise"],
  hardship: ["hardship", "difficulty", "difficult", "trial", "struggle", "patience", "stress"],
  dhikr: ["dhikr", "zikr", "remember", "remembrance", "tasbeeh", "tasbih", "peace"],
  reliance: ["rely", "reliance", "trust", "tawakkul", "decision", "help", "strength"],
  prayer: ["prayer", "salah", "salaah", "after salah", "worship"],
  prophet: ["prophet", "muhammad", "salawat", "blessing"],
  quran: ["quran", "qur'an", "verse", "ayah", "recite", "recitation"],
  law: ["law", "fiqh", "halal", "haram", "ruling", "fatwa", "madhhab", "school"],
};

export const ARABIC_AUDIO: Record<string, any> = {
  astaghfirullah: require('@/assets/audio/astaghfirullah.mp3'),
  la_ilaha_illallah: require('@/assets/audio/la_ilaha_illallah.mp3'),
  subhanallah: require('@/assets/audio/subhanallah.mp3'),
  alhamdulillah: require('@/assets/audio/alhamdulillah.mp3'),
  allahu_akbar: require('@/assets/audio/allahu_akbar.mp3'),
  quran_reading: require('@/assets/audio/quran_reading.mp3'),
  salawat: require('@/assets/audio/salawat.mp3'),
  hawqala: require('@/assets/audio/hawqala.mp3')
};

export const todayStr = () => new Date().toISOString().slice(0, 10);
export const dateNDaysAgo = (n: number) => {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString().slice(0, 10);
};

export function dailyDhikr() {
  const day = Math.floor((Date.parse(todayStr() + "T00:00:00Z") - Date.parse("2026-01-01T00:00:00Z")) / 86400000);
  const first = ((day % ADHKAR.length) + ADHKAR.length) % ADHKAR.length;
  return [ADHKAR[first], ADHKAR[(first + 1) % ADHKAR.length]];
}

export function dailyChallengeNumber() {
  const day = Math.floor((Date.parse(todayStr() + "T00:00:00Z") - Date.parse("2026-01-01T00:00:00Z")) / 86400000);
  return ((day % ADHKAR.length) + ADHKAR.length) % ADHKAR.length + 1;
}

export function practiceWindow() {
  const hour = new Date().getHours();
  if (hour < 5) return { label: "Before dawn", note: "A quiet moment before the day begins." };
  if (hour < 12) return { label: "Morning remembrance", note: "Begin with a heart turned toward Allah." };
  if (hour < 18) return { label: "Midday reset", note: "Return to presence between the day's demands." };
  if (hour < 22) return { label: "Evening remembrance", note: "Close the day with calm and gratitude." };
  return { label: "Night reflection", note: "A soft landing before rest." };
}

export const dailyHadith = () => {
  const day = Math.floor((Date.parse(todayStr() + "T00:00:00Z") - Date.parse("2026-01-01T00:00:00Z")) / 86400000);
  return HADITHS[((day % HADITHS.length) + HADITHS.length) % HADITHS.length];
};

export function searchIslamicLibrary(prompt: string) {
  const normalized = prompt.trim().toLowerCase();
  const directTerms = normalized.split(/[^a-z0-9']+/).filter(term => term.length > 2);
  const expanded = Object.entries(SEARCH_TOPIC_ALIASES)
    .filter(([, aliases]) => aliases.some(alias => normalized.includes(alias)))
    .flatMap(([topic]) => [topic, ...SEARCH_TOPIC_ALIASES[topic]]);
  
  const terms = [...new Set([...directTerms, ...expanded])];
  
  const score = (text: string) => {
    const haystack = text.toLowerCase();
    return terms.reduce((total, term) => total + (haystack.includes(term) ? (term.length > 5 ? 3 : 1) : 0), 0);
  };
  
  const results = [
    ...QURAN_REFERENCES.map(item => ({ ...item, type: "Qur’an", searchText: `${item.theme} ${item.reference} ${item.meaning}` })),
    ...HADITHS.map(item => ({ ...item, type: "Hadith", searchText: `${item.theme} ${item.title} ${item.text} ${item.reference}` })),
    ...ADHKAR.map(item => ({ ...item, type: "Dhikr", searchText: `${item.category} ${item.transliteration} ${item.meaning} ${item.moment} ${item.reflection} ${item.significance}` })),
  ].map(item => {
    const matchedTerms = terms.filter(term => item.searchText.toLowerCase().includes(term));
    return { ...item, matchedTerms, score: score(item.searchText) };
  })
  .filter(item => item.score > 0)
  .sort((a, b) => b.score - a.score);
  
  const lawPrompt = terms.some(term => ["law", "fiqh", "halal", "haram", "ruling", "fatwa", "madhhab"].includes(term));
  
  if (lawPrompt) {
    results.unshift({
      id: "law-boundary",
      type: "Guidance",
      title: "For a personal ruling, use a qualified scholar",
      theme: "Fiqh & law",
      meaning: "This search can point you toward sources, but it does not issue fatwas or decide between schools. Use the Library’s school-aware fiqh resources and include your context when asking a teacher.",
      reference: "School-aware guidance",
      score: 99,
      matchedTerms: ["fiqh"],
    } as any);
  }
  
  return { results, terms, lawPrompt };
}

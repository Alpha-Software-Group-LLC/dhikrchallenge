# The Dhikr Challenge

A quiet personal worship companion.

## Features
- Time-aware intention setting
- Local real Arabic, transliteration, and human recitation (audio)
- Haptic-enabled counter
- Private reflection and history
- Private Circles for shared practice without leaderboards
- Fully offline-capable local content with synced progress

## Environment
Ensure the backend API provides `https://${process.env.EXPO_PUBLIC_DOMAIN}/api/config` for Supabase credentials.

## Testing & Preview
On Replit, use the **Preview on your phone** tab to scan the QR code and test on your device using Expo Go.

## Release Preparation
This project is configured for building with Replit's Expo Launch. 
Click **Publish** on Replit to generate the iOS build and submit it to the App Store automatically.

import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, ActivityIndicator, Share, useWindowDimensions } from 'react-native';
import { useAuth } from '@/context/AuthContext';
import { useColors } from '@/hooks/useColors';
import { useMyCircles, useCircleToday, useCreateCircle, useJoinCircle, useSetCircleIntention } from '@/lib/hooks';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import * as Clipboard from 'expo-clipboard';

export default function CirclesScreen() {
  const { user } = useAuth();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const isTablet = width >= 768;
  
  const { data: circles, isLoading } = useMyCircles();
  const [selectedCircleId, setSelectedCircleId] = useState<string | null>(null);
  const activeId = selectedCircleId || (circles && circles.length > 0 ? circles[0].id : null);
  
  const { data: circleData, isLoading: loadingToday } = useCircleToday(activeId);
  const createCircle = useCreateCircle();
  const joinCircle = useJoinCircle();
  const setIntention = useSetCircleIntention();

  const [createName, setCreateName] = useState('');
  const [inviteCode, setInviteCode] = useState('');
  const [intentionInput, setIntentionInput] = useState('');
  
  const activeCircle = circles?.find(c => c.id === activeId);

  const handleCopy = async () => {
    if (activeCircle?.inviteCode) {
      await Clipboard.setStringAsync(activeCircle.inviteCode);
    }
  };

  const handleShare = async () => {
    if (activeCircle?.inviteCode) {
      await Share.share({
        message: `Join my private Dhikr Challenge circle "${activeCircle.name}" with invite code ${activeCircle.inviteCode}.`,
      });
    }
  };

  const handleCreate = () => {
    if (createName.trim()) {
      createCircle.mutate(createName.trim(), {
        onSuccess: () => setCreateName('')
      });
    }
  };

  const handleJoin = () => {
    if (inviteCode.trim()) {
      joinCircle.mutate(inviteCode.trim().toUpperCase(), {
        onSuccess: () => setInviteCode('')
      });
    }
  };

  const handleSetIntention = () => {
    if (activeId && intentionInput.trim()) {
      setIntention.mutate({ id: activeId, intention: intentionInput.trim() }, {
        onSuccess: () => setIntentionInput('')
      });
    }
  };

  if (isLoading) {
    return <View style={[styles.center, { backgroundColor: colors.background }]}><ActivityIndicator color={colors.amber} /></View>;
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 20, paddingBottom: insets.bottom + 100, maxWidth: isTablet ? 1000 : undefined }]}>
        
        <View style={styles.header}>
          <Text style={[styles.eyebrow, { color: colors.amber }]}>Practice together</Text>
          <Text style={[styles.title, { color: colors.text }]}>Your circles</Text>
          <Text style={[styles.subtitle, { color: colors.text2 }]}>
            Invite the people you love. See who has shown up for today’s challenge without turning worship into a competition.
          </Text>
        </View>

        <View style={[styles.actionRow, isTablet && styles.actionRowTablet]}>
          <View style={[styles.actionCard, isTablet && styles.actionCardTablet, { backgroundColor: colors.surface, borderColor: colors.border2 }]}>
            <Text style={[styles.actionTitle, { color: colors.green2 }]}>Create a circle</Text>
            <View style={styles.inputRow}>
              <TextInput 
                style={[styles.input, { backgroundColor: colors.bg2, borderColor: colors.border2, color: colors.text }]}
                placeholder="Family, friends, halaqah"
                placeholderTextColor={colors.text3}
                value={createName}
                onChangeText={setCreateName}
              />
              <TouchableOpacity 
                style={[styles.smallBtn, { backgroundColor: colors.amber, opacity: !createName.trim() ? 0.6 : 1 }]}
                onPress={handleCreate}
                disabled={!createName.trim() || createCircle.isPending}
              >
                <Text style={[styles.smallBtnText, { color: colors.bg2 }]}>Create</Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={[styles.actionCard, isTablet && styles.actionCardTablet, { backgroundColor: colors.surface, borderColor: colors.border2 }]}>
            <Text style={[styles.actionTitle, { color: colors.green2 }]}>Join with code</Text>
            <View style={styles.inputRow}>
              <TextInput 
                style={[styles.input, { backgroundColor: colors.bg2, borderColor: colors.border2, color: colors.text, fontFamily: 'Inter_500Medium', letterSpacing: 2 }]}
                placeholder="Invite code"
                placeholderTextColor={colors.text3}
                value={inviteCode}
                onChangeText={text => setInviteCode(text.toUpperCase().replace(/[^A-Z0-9]/g, ''))}
                autoCapitalize="characters"
              />
              <TouchableOpacity 
                style={[styles.smallBtnOutline, { backgroundColor: colors.greenDim, borderColor: colors.greenMid, opacity: !inviteCode.trim() ? 0.6 : 1 }]}
                onPress={handleJoin}
                disabled={!inviteCode.trim() || joinCircle.isPending}
              >
                <Text style={[styles.smallBtnText, { color: colors.green2 }]}>Join</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {!circles || circles.length === 0 ? (
          <View style={[styles.emptyCard, { backgroundColor: colors.bg2, borderColor: colors.border2 }]}>
            <Text style={[styles.emptyTitle, { color: colors.text }]}>Make remembrance a shared habit</Text>
            <Text style={[styles.emptyDesc, { color: colors.text2 }]}>
              Create a circle for your household or join one with an invite code. Your circle will appear here after the first person joins.
            </Text>
          </View>
        ) : (
          <>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.tabsRow}>
              {circles.map(c => (
                <TouchableOpacity 
                  key={c.id}
                  style={[
                    styles.tabChip, 
                    { 
                      backgroundColor: activeId === c.id ? colors.amberDim : colors.surface,
                      borderColor: activeId === c.id ? colors.amberMid : colors.border2
                    }
                  ]}
                  onPress={() => setSelectedCircleId(c.id)}
                >
                  <Text style={[styles.tabChipText, { color: activeId === c.id ? colors.amber2 : colors.text2 }]}>
                    {c.name} · {c.memberCount}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            {activeCircle && (
              <View style={[styles.circleCard, { backgroundColor: colors.surface, borderColor: colors.amberMid }]}>
                <View style={styles.circleHeader}>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.eyebrow, { color: colors.amber }]}>Today in</Text>
                    <Text style={[styles.circleTitle, { color: colors.text }]}>{activeCircle.name}</Text>
                    <Text style={[styles.circleMeta, { color: colors.text3 }]}>{activeCircle.memberCount} members · private</Text>
                  </View>
                  <View style={styles.shareActions}>
                    <TouchableOpacity style={[styles.shareBtn, { backgroundColor: colors.bg2, borderColor: colors.border2 }]} onPress={handleCopy}>
                      <Text style={[styles.shareBtnText, { color: colors.text2 }]}>Copy {activeCircle.inviteCode}</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.shareBtn, { backgroundColor: colors.greenDim, borderColor: colors.greenMid }]} onPress={handleShare}>
                      <Text style={[styles.shareBtnText, { color: colors.green2 }]}>Share</Text>
                    </TouchableOpacity>
                  </View>
                </View>

                <Text style={[styles.circleDesc, { color: colors.text3 }]}>
                  A gentle view of who has engaged with today’s Daily Challenge. No counts, streaks, or scores are shared.
                </Text>

                <View style={[styles.intentionBox, { backgroundColor: colors.bg2, borderColor: colors.border }]}>
                  <Text style={[styles.eyebrow, { color: colors.amber, marginBottom: 8 }]}>Today’s shared intention</Text>
                  {activeCircle.ownerId === user?.id ? (
                    <View style={styles.inputRow}>
                      <TextInput 
                        style={[styles.input, { flex: 1, backgroundColor: colors.surface, borderColor: colors.border2, color: colors.text }]}
                        placeholder="A small intention for the circle"
                        placeholderTextColor={colors.text3}
                        value={intentionInput}
                        onChangeText={setIntentionInput}
                      />
                      <TouchableOpacity 
                        style={[styles.smallBtnOutline, { backgroundColor: colors.amberDim, borderColor: colors.amberMid }]}
                        onPress={handleSetIntention}
                        disabled={!intentionInput.trim() || setIntention.isPending}
                      >
                        <Text style={[styles.smallBtnText, { color: colors.amber2 }]}>Save</Text>
                      </TouchableOpacity>
                    </View>
                  ) : (
                    <Text style={[styles.intentionText, { color: colors.text2 }]}>
                      {circleData?.intention || "The circle has not set an intention yet."}
                    </Text>
                  )}
                  {activeCircle.ownerId === user?.id && circleData?.intention ? (
                    <Text style={[styles.intentionSetText, { color: colors.text2, marginTop: 8 }]}>
                      Held by the circle: {circleData.intention}
                    </Text>
                  ) : null}
                </View>

                <View style={styles.membersList}>
                  {loadingToday ? (
                    <ActivityIndicator color={colors.amber} style={{ marginVertical: 20 }} />
                  ) : (
                    circleData?.members?.map((member: any, i: number) => (
                      <View key={i} style={[styles.memberRow, i < circleData.members.length - 1 && { borderBottomColor: colors.border, borderBottomWidth: 1 }]}>
                        <View style={[
                          styles.memberStatus, 
                          { 
                            backgroundColor: member.completedToday ? colors.greenDim : colors.raised,
                            borderColor: member.completedToday ? colors.greenMid : colors.border2 
                          }
                        ]}>
                          <Text style={{ color: member.completedToday ? colors.green : colors.text3, fontSize: 16, fontWeight: 'bold' }}>
                            {member.completedToday ? "✓" : "·"}
                          </Text>
                        </View>
                        <View style={{ flex: 1 }}>
                          <Text style={[styles.memberName, { color: member.currentUser ? colors.amber2 : colors.text, fontWeight: member.currentUser ? '600' : '400' }]}>
                            {member.name} {member.currentUser ? "· you" : ""}
                          </Text>
                          <Text style={[styles.memberSub, { color: colors.text3 }]}>
                            {member.completedToday ? "Joined today's practice" : "Not yet today"}
                          </Text>
                        </View>
                      </View>
                    ))
                  )}
                </View>
              </View>
            )}
          </>
        )}
        
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { width: '100%', alignSelf: 'center', paddingHorizontal: 20 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header: { marginBottom: 24 },
  eyebrow: { fontFamily: 'Inter_600SemiBold', fontSize: 11, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6 },
  title: { fontFamily: 'Inter_600SemiBold', fontSize: 26, marginBottom: 8 },
  subtitle: { fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 22 },
  
  actionRow: { gap: 12, marginBottom: 24 },
  actionRowTablet: { flexDirection: 'row' },
  actionCardTablet: { flex: 1 },
  actionCard: { padding: 16, borderRadius: 14, borderWidth: 1 },
  actionTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 12, marginBottom: 10 },
  inputRow: { flexDirection: 'row', gap: 8 },
  input: { flex: 1, height: 40, borderRadius: 8, borderWidth: 1, paddingHorizontal: 12, fontFamily: 'Inter_400Regular', fontSize: 14 },
  smallBtn: { height: 40, paddingHorizontal: 16, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  smallBtnOutline: { height: 40, paddingHorizontal: 16, borderRadius: 8, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  smallBtnText: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  
  emptyCard: { padding: 32, borderRadius: 16, borderWidth: 1, borderStyle: 'dashed', alignItems: 'center', marginTop: 16 },
  emptyTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 18, marginBottom: 8 },
  emptyDesc: { fontFamily: 'Inter_400Regular', fontSize: 14, textAlign: 'center', lineHeight: 22 },
  
  tabsRow: { gap: 8, paddingBottom: 16 },
  tabChip: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: 20, borderWidth: 1 },
  tabChipText: { fontFamily: 'Inter_500Medium', fontSize: 13 },
  
  circleCard: { borderRadius: 16, borderWidth: 1, padding: 20 },
  circleHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16, gap: 16 },
  circleTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 22, marginBottom: 4 },
  circleMeta: { fontFamily: 'Inter_400Regular', fontSize: 12 },
  shareActions: { gap: 8, alignItems: 'flex-end' },
  shareBtn: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8, borderWidth: 1 },
  shareBtnText: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  circleDesc: { fontFamily: 'Inter_400Regular', fontSize: 12, lineHeight: 18, marginBottom: 16 },
  
  intentionBox: { padding: 16, borderRadius: 12, borderWidth: 1, marginBottom: 16 },
  intentionText: { fontFamily: 'Inter_400Regular', fontSize: 14 },
  intentionSetText: { fontFamily: 'Inter_400Regular', fontSize: 13 },
  
  membersList: { borderTopWidth: 1, borderTopColor: 'transparent', paddingTop: 8 },
  memberRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 12 },
  memberStatus: { width: 32, height: 32, borderRadius: 16, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  memberName: { fontSize: 14, marginBottom: 2 },
  memberSub: { fontFamily: 'Inter_400Regular', fontSize: 12 },
});

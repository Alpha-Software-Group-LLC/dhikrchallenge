import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator, TextInput, KeyboardAvoidingView, Platform, useWindowDimensions } from 'react-native';
import { useAuth } from '@/context/AuthContext';
import { useColors } from '@/hooks/useColors';
import { useMyProgress, useMyExperience, useCompleteDhikr, useSaveReflection } from '@/lib/hooks';
import { practiceWindow, dailyHadith, dailyDhikr, dailyChallengeNumber, Dhikr } from '@/lib/data';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { TasbihCounter } from '@/components/TasbihCounter';
import { RecitationControls } from '@/components/RecitationControls';

export default function TodayScreen() {
  const { user } = useAuth();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  
  const { data: progress, isLoading: loadingProgress } = useMyProgress();
  const { data: experience } = useMyExperience();
  const completeDhikr = useCompleteDhikr();
  const saveReflection = useSaveReflection();

  const [activeTasbih, setActiveTasbih] = useState<Dhikr | null>(null);
  
  const [reflectionDhikrId, setReflectionDhikrId] = useState<string | null>(null);
  const [reflectionMood, setReflectionMood] = useState('reflective');
  const [reflectionNote, setReflectionNote] = useState('');

  if (loadingProgress || !progress) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.amber} size="large" />
      </View>
    );
  }

  const window = practiceWindow();
  const todayHadith = dailyHadith();
  const practiceDhks = dailyDhikr().slice(0, (experience?.preferences?.duration || 3) === 1 ? 1 : 2);
  const completedDhks = progress.completedToday || [];
  const completedReleases = practiceDhks.filter(d => completedDhks.includes(d.id)).length;
  const journeyProgress = completedReleases / practiceDhks.length;
  const showTransliteration = experience?.preferences?.showTransliteration !== false;
  const arabicSize = experience?.preferences?.arabicSize === 'extra' ? 40 : experience?.preferences?.arabicSize === 'regular' ? 28 : 34;
  
  const currentDhikr = practiceDhks[0];
  const challengeCompleted = completedDhks.includes(currentDhikr.id);
  const userName = (user?.user_metadata?.display_name || user?.email?.split("@")[0] || "Friend").split(" ")[0];

  const handleComplete = (dhikr: Dhikr) => {
    setActiveTasbih(null);
    completeDhikr.mutate(dhikr.id, {
      onSuccess: () => {
        setReflectionDhikrId(dhikr.id);
        setReflectionMood('reflective');
        setReflectionNote('');
      }
    });
  };

  const submitReflection = () => {
    if (!reflectionDhikrId) return;
    saveReflection.mutate({ id: reflectionDhikrId, mood: reflectionMood, note: reflectionNote.trim() }, {
      onSuccess: () => {
        setReflectionDhikrId(null);
      }
    });
  };

  const hasReflection = (dhikrId: string) => {
    return experience?.reflections?.some((r: any) => r.dhikrId === dhikrId && r.date === new Date().toISOString().slice(0, 10));
  };

  return (
    <KeyboardAvoidingView 
      style={[styles.container, { backgroundColor: colors.background }]} 
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 20, paddingBottom: insets.bottom + 100, maxWidth: width >= 768 ? 920 : undefined }]} keyboardShouldPersistTaps="handled">
        
        <View style={styles.header}>
          <View>
            <Text style={[styles.arabicGreeting, { color: colors.amber }]}>بِسْمِ ٱللَّهِ</Text>
            <Text style={[styles.title, { color: colors.text }]}>The Dhikr Challenge</Text>
            <Text style={[styles.subtitle, { color: colors.text2 }]}>Welcome back, {userName}</Text>
          </View>
          <TouchableOpacity onPress={() => router.push('/settings')} style={[styles.settingsButton, { backgroundColor: colors.surface, borderColor: colors.border2 }]}>
            <Text style={[styles.settingsText, { color: colors.text2 }]}>Preferences</Text>
          </TouchableOpacity>
        </View>

        <View style={[styles.card, { backgroundColor: colors.bg2, borderColor: colors.border }]}>
          <Text style={[styles.eyebrow, { color: colors.text3 }]}>Today’s intention</Text>
          <Text style={[styles.intention, { color: colors.text }]}>{(experience?.preferences?.goals || [])[0] || "Return to remembrance with presence"}</Text>
          <Text style={[styles.meta, { color: colors.text2 }]}>{experience?.preferences?.duration || 3} minute practice · Learn → Listen → Count → Reflect</Text>
        </View>

        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.greenMid, overflow: 'hidden' }]}>
          <View style={[styles.cardHeader, { marginBottom: 16 }]}>
            <View style={{ flex: 1 }}>
              <Text style={[styles.eyebrow, { color: colors.green2, letterSpacing: 1.2 }]}>Today’s daily challenge</Text>
              <Text style={[styles.cardTitle, { color: colors.text }]}>{window.label}</Text>
              <Text style={[styles.cardDesc, { color: colors.text2, marginTop: 4 }]}>{window.note}</Text>
            </View>
            <Text style={[styles.fraction, { color: colors.green2 }]}>{completedReleases}/{practiceDhks.length}</Text>
          </View>

          <View style={[styles.progressBarBg, { backgroundColor: colors.raised }]}>
            <View style={[styles.progressBarFill, { backgroundColor: colors.green, width: `${journeyProgress * 100}%` }]} />
          </View>

          <View style={[styles.cardFooter, { marginTop: 12 }]}>
            <Text style={[styles.footerText, { color: colors.text3, flex: 1, paddingRight: 10 }]}>
              {completedReleases === practiceDhks.length ? "Today’s practice is complete — carry the calm with you." : "Focused releases. No pressure, just return."}
            </Text>
            <Text style={[styles.footerStatus, { color: colors.green2 }]}>
              {completedReleases === practiceDhks.length ? "Complete" : "Begin"}
            </Text>
          </View>
        </View>

        <View style={[styles.primaryCard, { backgroundColor: colors.bg2, borderColor: colors.amberMid }]}>
          <Text style={[styles.eyebrow, { color: colors.amber, marginBottom: 6 }]}>Today's Challenge · Day {dailyChallengeNumber()}</Text>
          <Text style={[styles.mainArabic, { color: colors.amber2, fontSize: arabicSize, lineHeight: arabicSize * 1.38 }]}>{currentDhikr.arabic}</Text>
          {showTransliteration && <Text style={[styles.mainTransliteration, { color: colors.text }]}>{currentDhikr.transliteration}</Text>}
          <Text style={[styles.mainMeaning, { color: colors.text2 }]}>{currentDhikr.meaning} — {currentDhikr.target}×</Text>
          
          <View style={styles.controlsRow}>
            <Text style={[styles.audioHint, { color: colors.text3 }]}>Arabic-only recitation available</Text>
            <RecitationControls dhikrId={currentDhikr.id} meaning={currentDhikr.meaning} compact />
          </View>

          {!challengeCompleted ? (
            <TouchableOpacity 
              style={[styles.beginButton, { backgroundColor: colors.amber }]}
              onPress={() => setActiveTasbih(currentDhikr)}
            >
              <Text style={[styles.beginButtonText, { color: colors.bg2 }]}>Begin Dhikr · {currentDhikr.target}×</Text>
            </TouchableOpacity>
          ) : (
            <View style={[styles.completedBox, { backgroundColor: colors.greenDim, borderColor: colors.greenMid }]}>
              <Text style={[styles.completedTitle, { color: colors.green }]}>Challenge completed — MashaAllah!</Text>
              
              {reflectionDhikrId === currentDhikr.id && !hasReflection(currentDhikr.id) ? (
                <View style={styles.reflectionForm}>
                  <Text style={[styles.completedDesc, { color: colors.text3, marginBottom: 8 }]}>Take a moment to reflect (private).</Text>
                  
                  <View style={styles.moodRow}>
                    {['calm', 'reflective', 'grateful', 'heavy'].map(m => (
                      <TouchableOpacity 
                        key={m} 
                        style={[styles.moodChip, { backgroundColor: reflectionMood === m ? colors.amber : colors.surface, borderColor: reflectionMood === m ? colors.amber : colors.border2 }]}
                        onPress={() => setReflectionMood(m)}
                      >
                        <Text style={[styles.moodText, { color: reflectionMood === m ? colors.bg2 : colors.text2 }]}>{m}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                  
                  <TextInput 
                    style={[styles.refInput, { backgroundColor: colors.surface, borderColor: colors.border2, color: colors.text }]}
                    placeholder="What are you carrying today?"
                    placeholderTextColor={colors.text3}
                    value={reflectionNote}
                    onChangeText={setReflectionNote}
                    multiline
                  />
                  
                  <TouchableOpacity 
                    style={[styles.refSaveBtn, { backgroundColor: colors.amber, opacity: saveReflection.isPending ? 0.7 : 1 }]}
                    onPress={submitReflection}
                    disabled={saveReflection.isPending}
                  >
                    <Text style={[styles.refSaveText, { color: colors.bg2 }]}>{saveReflection.isPending ? "Saving..." : "Save reflection"}</Text>
                  </TouchableOpacity>
                </View>
              ) : (
                <Text style={[styles.completedDesc, { color: colors.text3 }]}>
                  {hasReflection(currentDhikr.id) ? "You added a reflection." : "Your reflection can stay private to you."}
                </Text>
              )}
            </View>
          )}
        </View>

        {practiceDhks[1] && (() => {
          const d = practiceDhks[1];
          const done = completedDhks.includes(d.id);
          return (
            <View style={[styles.secondaryCard, { backgroundColor: colors.surface, borderColor: colors.border2 }]}>
              <View style={styles.cardHeader}>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.eyebrow, { color: colors.green }]}>Today's second release</Text>
                  <Text style={[styles.secArabic, { color: colors.text }]}>{d.arabic}</Text>
                  <Text style={[styles.secTrans, { color: colors.text2 }]}>{showTransliteration ? `${d.transliteration} · ` : ''}{d.target}×</Text>
                </View>
                <RecitationControls dhikrId={d.id} meaning={d.meaning} compact />
              </View>
              
              {!done ? (
                <TouchableOpacity 
                  style={[styles.secBeginButton, { backgroundColor: colors.greenDim, borderColor: colors.greenMid }]}
                  onPress={() => setActiveTasbih(d)}
                >
                  <Text style={[styles.secBeginText, { color: colors.green2 }]}>Begin Dhikr · {d.target}×</Text>
                </TouchableOpacity>
              ) : (
                <View style={[styles.secCompletedBox, { backgroundColor: colors.greenDim }]}>
                  <Text style={[styles.secCompletedText, { color: colors.green }]}>Completed today — MashaAllah</Text>
                </View>
              )}
            </View>
          );
        })()}

        <View style={[styles.infoCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.eyebrow, { color: colors.amber }]}>Why This Dhikr Matters</Text>
          <Text style={[styles.infoBody, { color: colors.text }]}>{currentDhikr.significance}</Text>
          
          <View style={[styles.divider, { borderTopColor: colors.border2 }]} />
          
          <Text style={[styles.eyebrow, { color: colors.amber }]}>A reflection for practice</Text>
          <Text style={[styles.reflectionItalic, { color: colors.text2 }]}>{currentDhikr.practiceReflection}</Text>
          <Text style={[styles.disclaimer, { color: colors.text3 }]}>A meditation, not a hadith or fatwa. For rulings or personal guidance, ask a qualified scholar.</Text>
        </View>

        <View style={[styles.infoCard, { backgroundColor: colors.surface, borderColor: colors.greenMid }]}>
          <View style={[styles.cardHeader, { marginBottom: 12 }]}>
            <Text style={[styles.eyebrow, { color: colors.green2 }]}>A hadith to carry</Text>
            <Text style={[styles.hadithTheme, { color: colors.text3 }]}>{todayHadith.theme}</Text>
          </View>
          <Text style={[styles.hadithText, { color: colors.text }]}>{todayHadith.text}</Text>
          <Text style={[styles.hadithRef, { color: colors.text3 }]}>Paraphrase · {todayHadith.reference}</Text>
        </View>

      </ScrollView>

      {activeTasbih && (
        <TasbihCounter 
          visible={!!activeTasbih} 
          dhikr={activeTasbih} 
          onClose={() => setActiveTasbih(null)} 
          onComplete={handleComplete} 
        />
      )}
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { width: '100%', alignSelf: 'center', paddingHorizontal: 20 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 },
  arabicGreeting: { fontFamily: 'Amiri_400Regular', fontSize: 18, marginBottom: 2, textAlign: 'right' },
  title: { fontFamily: 'CormorantGaramond_600SemiBold', fontSize: 30, letterSpacing: -0.3 },
  subtitle: { fontFamily: 'Outfit_400Regular', fontSize: 14, marginTop: 4 },
  settingsButton: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8, borderWidth: 1 },
  settingsText: { fontFamily: 'Inter_500Medium', fontSize: 12 },
  
  card: { borderRadius: 16, padding: 20, borderWidth: 1, marginBottom: 16 },
  eyebrow: { fontFamily: 'Inter_600SemiBold', fontSize: 11, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 8 },
  intention: { fontFamily: 'Inter_500Medium', fontSize: 16, marginBottom: 6 },
  meta: { fontFamily: 'Inter_400Regular', fontSize: 13 },
  
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  cardTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 20 },
  cardDesc: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 20 },
  fraction: { fontFamily: 'Inter_500Medium', fontSize: 14 },
  
  progressBarBg: { height: 6, borderRadius: 3, overflow: 'hidden' },
  progressBarFill: { height: '100%', borderRadius: 3 },
  
  cardFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  footerText: { fontFamily: 'Inter_400Regular', fontSize: 12, lineHeight: 16 },
  footerStatus: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  
  primaryCard: { borderRadius: 20, padding: 24, borderWidth: 1, marginBottom: 16 },
  mainArabic: { fontFamily: 'Amiri_400Regular', fontSize: 32, textAlign: 'right', marginBottom: 12, lineHeight: 44 },
  mainTransliteration: { fontFamily: 'Lora_400Regular_Italic', fontSize: 16, marginBottom: 4 },
  mainMeaning: { fontFamily: 'Lora_400Regular', fontSize: 14, marginBottom: 20 },
  controlsRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  audioHint: { fontFamily: 'Inter_400Regular', fontSize: 11 },
  
  beginButton: { paddingVertical: 16, borderRadius: 12, alignItems: 'center' },
  beginButtonText: { fontFamily: 'Inter_600SemiBold', fontSize: 15 },
  
  completedBox: { padding: 16, borderRadius: 12, borderWidth: 1 },
  completedTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 14, marginBottom: 4 },
  completedDesc: { fontFamily: 'Inter_400Regular', fontSize: 12 },
  
  reflectionForm: { marginTop: 12, paddingTop: 12, borderTopWidth: 1 },
  moodRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 12 },
  moodChip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, borderWidth: 1 },
  moodText: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  refInput: { height: 80, borderRadius: 8, borderWidth: 1, padding: 12, fontFamily: 'Inter_400Regular', fontSize: 14, textAlignVertical: 'top', marginBottom: 12 },
  refSaveBtn: { paddingVertical: 12, borderRadius: 8, alignItems: 'center' },
  refSaveText: { fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  
  secondaryCard: { borderRadius: 16, padding: 16, borderWidth: 1, marginBottom: 16 },
  secArabic: { fontFamily: 'Amiri_400Regular', fontSize: 26, textAlign: 'right', marginBottom: 4 },
  secTrans: { fontFamily: 'Inter_400Regular', fontSize: 13 },
  secBeginButton: { paddingVertical: 14, borderRadius: 10, alignItems: 'center', borderWidth: 1, marginTop: 12 },
  secBeginText: { fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  secCompletedBox: { paddingVertical: 12, borderRadius: 10, alignItems: 'center', marginTop: 12 },
  secCompletedText: { fontFamily: 'Inter_500Medium', fontSize: 13 },
  
  infoCard: { borderRadius: 16, padding: 20, borderWidth: 1, marginBottom: 16 },
  infoBody: { fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 22, marginBottom: 16 },
  divider: { borderTopWidth: 1, paddingTop: 16, marginBottom: 8 },
  reflectionItalic: { fontFamily: 'Lora_400Regular_Italic', fontSize: 14, lineHeight: 22, marginBottom: 12 },
  disclaimer: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 16 },
  
  hadithTheme: { fontFamily: 'Inter_400Regular', fontSize: 11 },
  hadithText: { fontFamily: 'Lora_400Regular', fontSize: 15, lineHeight: 24, marginBottom: 12 },
  hadithRef: { fontFamily: 'Inter_400Regular', fontSize: 11 },
});

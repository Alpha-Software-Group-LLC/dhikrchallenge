import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, TouchableOpacity, Keyboard, useWindowDimensions } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { searchIslamicLibrary } from '@/lib/data';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';

export default function AskScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const isTablet = width >= 768;
  
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [searched, setSearched] = useState(false);

  const handleSearch = () => {
    Keyboard.dismiss();
    if (!query.trim()) {
      setResults([]);
      setSearched(false);
      return;
    }
    const res = searchIslamicLibrary(query);
    setResults(res.results);
    setSearched(true);
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <KeyboardAwareScrollViewCompat contentContainerStyle={[styles.content, { paddingTop: insets.top + 20, paddingBottom: insets.bottom + 100, maxWidth: isTablet ? 1000 : undefined }]} keyboardShouldPersistTaps="handled">
        
        <View style={styles.header}>
          <Text style={[styles.eyebrow, { color: colors.amber }]}>Search & Find</Text>
          <Text style={[styles.title, { color: colors.text }]}>Ask</Text>
          <Text style={[styles.subtitle, { color: colors.text2 }]}>
            Search the curated library for guidance, comfort, or specific adhkar.
          </Text>
        </View>

        <View style={styles.searchBox}>
          <TextInput 
            style={[styles.input, { backgroundColor: colors.surface, borderColor: colors.border2, color: colors.text }]}
            placeholder="e.g., anxiety, forgiveness, gratitude"
            placeholderTextColor={colors.text3}
            value={query}
            onChangeText={setQuery}
            onSubmitEditing={handleSearch}
            returnKeyType="search"
          />
          <TouchableOpacity 
            style={[styles.searchBtn, { backgroundColor: colors.amber }]}
            onPress={handleSearch}
          >
            <Feather name="search" size={20} color={colors.bg2} />
          </TouchableOpacity>
        </View>

        {searched && (
          <View style={styles.resultsArea}>
            {results.length > 0 ? (
              <>
                <Text style={[styles.resultCount, { color: colors.text3 }]}>Found {results.length} related items</Text>
                <View style={[styles.list, isTablet && styles.tabletList]}>
                  {results.map((item, i) => (
                    <View key={item.id + i} style={[styles.card, isTablet && styles.tabletCard, { backgroundColor: colors.surface, borderColor: item.type === 'Guidance' ? colors.roseDim : colors.border }]}>
                      <View style={styles.cardHeader}>
                        <Text style={[styles.cardType, { color: item.type === 'Guidance' ? colors.rose : colors.green2 }]}>{item.type}</Text>
                        {item.matchedTerms && item.matchedTerms.length > 0 && (
                          <Text style={[styles.cardTags, { color: colors.text3 }]}>{item.matchedTerms.join(", ")}</Text>
                        )}
                      </View>
                      
                      {item.arabic && <Text style={[styles.cardArabic, { color: colors.amber2 }]}>{item.arabic}</Text>}
                      {item.transliteration && <Text style={[styles.cardTrans, { color: colors.text }]}>{item.transliteration}</Text>}
                      
                      <Text style={[styles.cardTitle, { color: colors.text }]}>{item.title || item.meaning}</Text>
                      {item.text && <Text style={[styles.cardDesc, { color: colors.text2, marginTop: 8 }]}>{item.text}</Text>}
                      {item.significance && <Text style={[styles.cardDesc, { color: colors.text2, marginTop: 8 }]}>{item.significance}</Text>}
                      
                      {(item.reference || item.source) && (
                        <Text style={[styles.cardRef, { color: colors.text3 }]}>{item.reference || item.source}</Text>
                      )}
                    </View>
                  ))}
                </View>
              </>
            ) : (
              <View style={[styles.emptyBox, { backgroundColor: colors.bg2, borderColor: colors.border2 }]}>
                <Text style={[styles.emptyText, { color: colors.text2 }]}>No direct matches found in the curated library. Try a broader term like "peace" or "hardship".</Text>
              </View>
            )}
          </View>
        )}

      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { width: '100%', alignSelf: 'center', paddingHorizontal: 20 },
  header: { marginBottom: 24 },
  eyebrow: { fontFamily: 'Inter_600SemiBold', fontSize: 11, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6 },
  title: { fontFamily: 'Inter_600SemiBold', fontSize: 28, marginBottom: 8 },
  subtitle: { fontFamily: 'Inter_400Regular', fontSize: 15, lineHeight: 22 },
  
  searchBox: { flexDirection: 'row', gap: 12, marginBottom: 32 },
  input: { flex: 1, height: 50, borderRadius: 12, borderWidth: 1, paddingHorizontal: 16, fontSize: 16, fontFamily: 'Inter_400Regular' },
  searchBtn: { width: 50, height: 50, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  
  resultsArea: { flex: 1 },
  resultCount: { fontFamily: 'Inter_500Medium', fontSize: 13, marginBottom: 16 },
  list: { gap: 16 },
  tabletList: { flexDirection: 'row', flexWrap: 'wrap' },
  
  card: { padding: 20, borderRadius: 16, borderWidth: 1 },
  tabletCard: { width: '48.8%' },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  cardType: { fontFamily: 'Inter_600SemiBold', fontSize: 11, textTransform: 'uppercase', letterSpacing: 1 },
  cardTags: { fontFamily: 'Inter_400Regular', fontSize: 11, fontStyle: 'italic' },
  
  cardArabic: { fontFamily: 'Inter_400Regular', fontSize: 24, textAlign: 'right', marginBottom: 8, lineHeight: 36 },
  cardTrans: { fontFamily: 'Inter_500Medium', fontSize: 15, marginBottom: 4 },
  cardTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 16 },
  cardDesc: { fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 22 },
  cardRef: { fontFamily: 'Inter_400Regular', fontSize: 12, fontStyle: 'italic', marginTop: 12 },
  
  emptyBox: { padding: 24, borderRadius: 12, borderWidth: 1, borderStyle: 'dashed', alignItems: 'center' },
  emptyText: { fontFamily: 'Inter_400Regular', fontSize: 14, textAlign: 'center', lineHeight: 22 },
});

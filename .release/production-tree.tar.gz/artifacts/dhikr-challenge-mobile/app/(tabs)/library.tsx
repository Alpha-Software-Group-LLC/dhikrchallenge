import React, { useMemo, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, useWindowDimensions } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { ADHKAR, HADITHS, QURAN_REFERENCES, QURAN_READING_PATHS } from '@/lib/data';
import { useMyExperience, useToggleSaved } from '@/lib/hooks';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';

type Section = 'Adhkar' | 'Qur’an' | 'Hadith' | 'Arabic' | 'Guidance' | 'Tools';

const guidance = [
  { id: 'scholar', title: 'When to ask a scholar', body: 'Personal circumstances and rulings deserve a qualified teacher who knows your context. This library offers sources, not verdicts.' },
  { id: 'schools', title: 'Respecting valid differences', body: 'Schools of thought may differ in details while sharing the same roots. Your preference helps frame boundaries; it does not rank one school over another.' },
  { id: 'source', title: 'Read with the source visible', body: 'References stay beside each reminder so you can verify, study further, and avoid treating a reflection as revelation.' },
];

export default function LibraryScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const isTablet = width >= 768;
  const [section, setSection] = useState<Section>('Adhkar');
  const { data: experience } = useMyExperience();
  const toggleSaved = useToggleSaved();
  const savedItems = experience?.savedItems || [];

  const isSaved = (type: string, id: string) => savedItems.some((item: any) =>
    (item.itemType === type || item.item_type === type || item.type === type) &&
    (item.itemId === id || item.item_id === id || item.id === id)
  );

  const arabicWords = useMemo(() => {
    const seen = new Set<string>();
    return ADHKAR.flatMap((dhikr) => (dhikr.words || []).map(([arabic, transliteration, meaning]) => ({
      id: `${dhikr.id}-${arabic}`,
      arabic,
      transliteration,
      meaning,
      from: dhikr.transliteration,
    }))).filter((word) => {
      if (seen.has(word.arabic)) return false;
      seen.add(word.arabic);
      return true;
    });
  }, []);

  const SaveButton = ({ type, id }: { type: string; id: string }) => {
    const saved = isSaved(type, id);
    return (
      <TouchableOpacity
        accessibilityLabel={saved ? 'Remove saved item' : 'Save item'}
        style={[styles.saveButton, { backgroundColor: saved ? colors.amberDim : colors.bg2, borderColor: saved ? colors.amberMid : colors.border }]}
        onPress={() => toggleSaved.mutate({ type, id })}
        disabled={toggleSaved.isPending}
      >
        <Feather name={saved ? 'bookmark' : 'bookmark'} size={16} color={saved ? colors.amber2 : colors.text3} />
      </TouchableOpacity>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 20, paddingBottom: insets.bottom + 100, maxWidth: isTablet ? 1060 : undefined }]}>
        <View style={styles.header}>
          <Text style={[styles.eyebrow, { color: colors.amber }]}>Knowledge & Roots</Text>
          <Text style={[styles.title, { color: colors.text }]}>Library</Text>
          <Text style={[styles.subtitle, { color: colors.text2 }]}>Curated adhkar, Qur’an references, prophetic guidance, Arabic word study, and practical reading paths.</Text>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.sectionTabs}>
          {(['Adhkar', 'Qur’an', 'Hadith', 'Arabic', 'Guidance', 'Tools'] as Section[]).map((item) => (
            <TouchableOpacity
              key={item}
              style={[styles.sectionTab, { backgroundColor: section === item ? colors.amberDim : colors.surface, borderColor: section === item ? colors.amberMid : colors.border }]}
              onPress={() => setSection(item)}
            >
              <Text style={[styles.sectionTabText, { color: section === item ? colors.amber2 : colors.text2 }]}>{item}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <View style={[styles.grid, isTablet && styles.tabletGrid]}>
          {section === 'Adhkar' && ADHKAR.map((d) => (
            <View key={d.id} style={[styles.card, isTablet && styles.tabletCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <View style={styles.cardHeader}><Text style={[styles.cardCategory, { color: colors.green2 }]}>{d.category}</Text><SaveButton type="dhikr" id={d.id} /></View>
              <Text style={[styles.cardArabic, { color: colors.amber2 }]}>{d.arabic}</Text>
              <Text style={[styles.cardTrans, { color: colors.text }]}>{d.transliteration} · {d.target}×</Text>
              <Text style={[styles.cardMeaning, { color: colors.text2 }]}>{d.meaning}</Text>
              <Text style={[styles.cardSig, { color: colors.text3 }]}>{d.significance}</Text>
              <Text style={[styles.cardRef, { color: colors.text3 }]}>{d.source}</Text>
            </View>
          ))}

          {section === 'Qur’an' && QURAN_REFERENCES.map((item) => (
            <View key={item.id} style={[styles.card, isTablet && styles.tabletCard, { backgroundColor: colors.surface, borderColor: colors.greenMid }]}>
              <View style={styles.cardHeader}><Text style={[styles.cardCategory, { color: colors.green2 }]}>{item.reference}</Text><SaveButton type="quran" id={item.id} /></View>
              <Text style={[styles.cardMeaning, { color: colors.text }]}>{item.meaning}</Text>
              <Text style={[styles.cardSig, { color: colors.text3 }]}>Themes: {item.theme}</Text>
            </View>
          ))}

          {section === 'Hadith' && HADITHS.map((h) => (
            <View key={h.id} style={[styles.card, isTablet && styles.tabletCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <View style={styles.cardHeader}><Text style={[styles.cardCategory, { color: colors.amber }]}>{h.theme}</Text><SaveButton type="hadith" id={h.id} /></View>
              <Text style={[styles.cardTitle, { color: colors.text }]}>{h.title}</Text>
              <Text style={[styles.cardMeaning, { color: colors.text2 }]}>{h.text}</Text>
              <Text style={[styles.cardRef, { color: colors.text3 }]}>{h.reference}</Text>
            </View>
          ))}

          {section === 'Arabic' && arabicWords.map((word) => (
            <View key={word.id} style={[styles.wordCard, isTablet && styles.wordCardTablet, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <Text style={[styles.wordArabic, { color: colors.amber2 }]}>{word.arabic}</Text>
              <Text style={[styles.wordTrans, { color: colors.text }]}>{word.transliteration}</Text>
              <Text style={[styles.wordMeaning, { color: colors.text2 }]}>{word.meaning}</Text>
              <Text style={[styles.cardRef, { color: colors.text3 }]}>From {word.from}</Text>
            </View>
          ))}

          {section === 'Guidance' && guidance.map((item) => (
            <View key={item.id} style={[styles.card, isTablet && styles.tabletCard, { backgroundColor: colors.surface, borderColor: colors.roseDim }]}>
              <Text style={[styles.cardCategory, { color: colors.rose }]}>Guidance boundary</Text>
              <Text style={[styles.cardTitle, { color: colors.text }]}>{item.title}</Text>
              <Text style={[styles.cardMeaning, { color: colors.text2 }]}>{item.body}</Text>
            </View>
          ))}

          {section === 'Tools' && QURAN_READING_PATHS.map((path) => (
            <View key={path.title} style={[styles.card, isTablet && styles.tabletCard, { backgroundColor: colors.surface, borderColor: colors.amberMid }]}>
              <Text style={[styles.cardCategory, { color: colors.amber }]}>Reading path</Text>
              <Text style={[styles.cardTitle, { color: colors.text }]}>{path.title}</Text>
              <Text style={[styles.cardMeaning, { color: colors.text2 }]}>{path.description}</Text>
              <Text style={[styles.cardRef, { color: colors.text3 }]}>{path.items.map((id) => QURAN_REFERENCES.find((item) => item.id === id)?.reference).filter(Boolean).join(' · ')}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { width: '100%', alignSelf: 'center', paddingHorizontal: 20 },
  header: { marginBottom: 24 },
  eyebrow: { fontFamily: 'Inter_600SemiBold', fontSize: 11, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6 },
  title: { fontFamily: 'CormorantGaramond_600SemiBold', fontSize: 34, marginBottom: 8 },
  subtitle: { fontFamily: 'Outfit_400Regular', fontSize: 15, lineHeight: 22, maxWidth: 680 },
  sectionTabs: { gap: 8, paddingBottom: 24 },
  sectionTab: { minHeight: 44, paddingHorizontal: 16, borderRadius: 22, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  sectionTabText: { fontFamily: 'Inter_500Medium', fontSize: 13 },
  grid: { gap: 16 },
  tabletGrid: { flexDirection: 'row', flexWrap: 'wrap' },
  card: { padding: 20, borderRadius: 16, borderWidth: 1 },
  tabletCard: { width: '48.8%' },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  cardCategory: { fontFamily: 'Inter_600SemiBold', fontSize: 11, textTransform: 'uppercase', letterSpacing: 1 },
  cardArabic: { fontFamily: 'Amiri_400Regular', fontSize: 28, textAlign: 'right', marginBottom: 12, lineHeight: 40 },
  cardTrans: { fontFamily: 'Lora_400Regular_Italic', fontSize: 16, marginBottom: 4 },
  cardMeaning: { fontFamily: 'Lora_400Regular', fontSize: 14, lineHeight: 22, marginTop: 8 },
  cardSig: { fontFamily: 'Inter_400Regular', fontSize: 12, lineHeight: 18, fontStyle: 'italic', marginTop: 12 },
  cardRef: { fontFamily: 'Inter_400Regular', fontSize: 11, fontStyle: 'italic', marginTop: 12 },
  cardTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 17, marginTop: 10 },
  saveButton: { width: 40, height: 40, borderRadius: 20, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  wordCard: { padding: 18, borderRadius: 14, borderWidth: 1 },
  wordCardTablet: { width: '31.8%' },
  wordArabic: { fontFamily: 'Amiri_400Regular', fontSize: 30, textAlign: 'right', marginBottom: 8 },
  wordTrans: { fontFamily: 'Inter_600SemiBold', fontSize: 15 },
  wordMeaning: { fontFamily: 'Inter_400Regular', fontSize: 13, marginTop: 4 },
});
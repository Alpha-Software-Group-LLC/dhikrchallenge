import React, { useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator, useWindowDimensions } from 'react-native';
import { useAuth } from '@/context/AuthContext';
import { useColors } from '@/hooks/useColors';
import { useMyProgress, useMyExperience } from '@/lib/hooks';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { dateNDaysAgo } from '@/lib/data';

export default function JourneyScreen() {
  const { user } = useAuth();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  
  const { data: progress, isLoading: loadingProgress } = useMyProgress();
  const { data: experience, isLoading: loadingExp } = useMyExperience();

  const series = useMemo(() => {
    if (!progress) return [];
    const map: any = {};
    progress.history.forEach((h: any) => { map[h.date] = h; });
    const out = [];
    for (let i = 13; i >= 0; i--) {
      const ds = dateNDaysAgo(i);
      out.push({ date: ds, completions: map[ds] ? map[ds].completions : 0 });
    }
    return out;
  }, [progress]);

  if (loadingProgress || loadingExp) {
    return <View style={[styles.center, { backgroundColor: colors.background }]}><ActivityIndicator color={colors.amber} /></View>;
  }

  const activeDays = progress?.history.filter((h: any) => h.completions > 0).length || 0;
  const userName = (user?.user_metadata?.display_name || user?.email?.split("@")[0] || "Friend").split(" ")[0];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 20, paddingBottom: insets.bottom + 100, maxWidth: width >= 768 ? 920 : undefined }]}>
        
        <View style={styles.header}>
          <Text style={[styles.eyebrow, { color: colors.amber }]}>Spiritual Journey</Text>
          <Text style={[styles.title, { color: colors.text }]}>A quiet record of returning</Text>
          <Text style={[styles.subtitle, { color: colors.text2 }]}>{userName}</Text>
        </View>

        <View style={[styles.statsCard, { backgroundColor: colors.bg2, borderColor: colors.border2 }]}>
          <View style={styles.statBox}>
            <Text style={[styles.statValue, { color: colors.text }]}>{activeDays}</Text>
            <Text style={[styles.statLabel, { color: colors.text3 }]}>Active days</Text>
          </View>
          <View style={styles.statBox}>
            <Text style={[styles.statValue, { color: colors.text }]}>{progress?.totalCompletions || 0}</Text>
            <Text style={[styles.statLabel, { color: colors.text3 }]}>Total practices</Text>
          </View>
        </View>

        <View style={[styles.chartCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.eyebrow, { color: colors.green2, marginBottom: 16 }]}>Last 14 Days</Text>
          <View style={styles.chartArea}>
            {series.map((day, i) => {
              const h = day.completions * 20; 
              const isToday = i === series.length - 1;
              return (
                <View key={day.date} style={styles.barColumn}>
                  <View style={[styles.barBg, { backgroundColor: colors.bg2, height: 60 }]}>
                    <View style={[styles.barFill, { backgroundColor: isToday ? colors.green2 : colors.greenMid, height: Math.max(h, 4) }]} />
                  </View>
                  <Text style={[styles.barLabel, { color: colors.text3 }]}>{isToday ? "T" : day.date.slice(8, 10)}</Text>
                </View>
              );
            })}
          </View>
          <Text style={[styles.chartDesc, { color: colors.text3 }]}>
            Consistency is beautiful, but the goal is presence, not a perfect streak. A missed day is simply an invitation to begin again.
          </Text>
        </View>

        <Text style={[styles.sectionTitle, { color: colors.text, marginTop: 24 }]}>Private Reflections</Text>
        
        {experience?.reflections && experience.reflections.length > 0 ? (
          <View style={styles.reflectionsList}>
            {experience.reflections.map((ref: any, idx: number) => (
              <View key={idx} style={[styles.reflectionCard, { backgroundColor: colors.surface, borderColor: colors.border2 }]}>
                <View style={styles.reflectionHeader}>
                  <Text style={[styles.refDate, { color: colors.text3 }]}>{new Date(ref.created_at).toLocaleDateString()}</Text>
                  <View style={[styles.moodTag, { backgroundColor: colors.amberDim }]}>
                    <Text style={[styles.moodText, { color: colors.amber2 }]}>{ref.mood}</Text>
                  </View>
                </View>
                {ref.note ? (
                  <Text style={[styles.refNote, { color: colors.text }]}>{ref.note}</Text>
                ) : (
                  <Text style={[styles.refNoteEmpty, { color: colors.text3 }]}>Completed without a written reflection.</Text>
                )}
              </View>
            ))}
          </View>
        ) : (
          <View style={[styles.emptyReflections, { backgroundColor: colors.bg2, borderColor: colors.border2 }]}>
            <Text style={[styles.emptyText, { color: colors.text2 }]}>Your private reflections will appear here as you complete the daily practice.</Text>
          </View>
        )}

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { width: '100%', alignSelf: 'center', paddingHorizontal: 20 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header: { marginBottom: 24 },
  eyebrow: { fontFamily: 'Inter_600SemiBold', fontSize: 11, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 6 },
  title: { fontFamily: 'Inter_600SemiBold', fontSize: 26, marginBottom: 8 },
  subtitle: { fontFamily: 'Inter_400Regular', fontSize: 14 },
  
  statsCard: { flexDirection: 'row', padding: 20, borderRadius: 16, borderWidth: 1, marginBottom: 16 },
  statBox: { flex: 1, alignItems: 'center' },
  statValue: { fontFamily: 'Inter_600SemiBold', fontSize: 24, marginBottom: 4 },
  statLabel: { fontFamily: 'Inter_500Medium', fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 },
  
  chartCard: { padding: 20, borderRadius: 16, borderWidth: 1, marginBottom: 24 },
  chartArea: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', height: 80, marginBottom: 16 },
  barColumn: { alignItems: 'center', flex: 1 },
  barBg: { width: 12, borderRadius: 6, justifyContent: 'flex-end', overflow: 'hidden' },
  barFill: { width: '100%', borderRadius: 6 },
  barLabel: { fontFamily: 'Inter_500Medium', fontSize: 10, marginTop: 8 },
  chartDesc: { fontFamily: 'Inter_400Regular', fontSize: 12, lineHeight: 18, fontStyle: 'italic', textAlign: 'center' },
  
  sectionTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 18, marginBottom: 16 },
  reflectionsList: { gap: 12 },
  reflectionCard: { padding: 16, borderRadius: 12, borderWidth: 1 },
  reflectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  refDate: { fontFamily: 'Inter_500Medium', fontSize: 12 },
  moodTag: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 },
  moodText: { fontFamily: 'Inter_600SemiBold', fontSize: 10, textTransform: 'uppercase', letterSpacing: 0.5 },
  refNote: { fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 22 },
  refNoteEmpty: { fontFamily: 'Inter_400Regular', fontSize: 14, fontStyle: 'italic' },
  
  emptyReflections: { padding: 24, borderRadius: 12, borderWidth: 1, borderStyle: 'dashed', alignItems: 'center' },
  emptyText: { fontFamily: 'Inter_400Regular', fontSize: 14, textAlign: 'center', lineHeight: 22 },
});

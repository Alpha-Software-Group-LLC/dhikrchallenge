import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch, TextInput, useWindowDimensions } from 'react-native';
import { useAuth } from '@/context/AuthContext';
import { useColors } from '@/hooks/useColors';
import { useMyExperience, useSavePreferences } from '@/lib/hooks';
import { Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';

export default function SettingsScreen() {
  const { signOut, user } = useAuth();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const { data: experience } = useMyExperience();
  const savePreferences = useSavePreferences();

  const [prefs, setPrefs] = useState(experience?.preferences || {
    duration: 3,
    audio: "arabic",
    reminder: "",
    school: "",
    goals: [],
    arabicSize: "large",
    showTransliteration: true,
  });

  useEffect(() => {
    if (experience?.preferences) setPrefs((current: any) => ({ ...current, ...experience.preferences }));
  }, [experience?.preferences]);
  
  const goalsOptions = ["A calmer daily rhythm", "Understanding the words", "Returning after salah", "A private practice with family"];

  const handleSave = () => {
    savePreferences.mutate({ ...prefs, onboardingCompleted: true }, {
      onSuccess: () => {
        router.back();
      }
    });
  };

  const toggleGoal = (g: string) => {
    const current = prefs.goals || [];
    if (current.includes(g)) {
      setPrefs({ ...prefs, goals: current.filter((x: string) => x !== g) });
    } else {
      setPrefs({ ...prefs, goals: [...current, g] });
    }
  };

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 40, paddingTop: 20, maxWidth: width >= 768 ? 760 : undefined }]}
    >
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.text }]}>Preferences</Text>
        <TouchableOpacity onPress={() => router.back()} style={[styles.closeButton, { backgroundColor: colors.surface, borderColor: colors.border2 }]}>
          <Feather name="x" size={20} color={colors.text2} />
        </TouchableOpacity>
      </View>

      <Text style={[styles.description, { color: colors.text2 }]}>Adjust the shape of your daily return. Nothing here is public.</Text>

      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: colors.text }]}>Practice duration</Text>
        <View style={[styles.rowGroup, { backgroundColor: colors.surface, borderColor: colors.border2 }]}>
          {[1, 3, 5].map((val, i) => (
            <TouchableOpacity 
              key={val} 
              style={[
                styles.rowItem, 
                i > 0 && { borderTopWidth: 1, borderTopColor: colors.border2 },
                prefs.duration === val && { backgroundColor: colors.amberDim }
              ]}
              onPress={() => setPrefs({ ...prefs, duration: val })}
            >
              <Text style={[styles.rowText, { color: prefs.duration === val ? colors.amber2 : colors.text }]}>{val} minutes</Text>
              {prefs.duration === val && <Feather name="check" size={18} color={colors.amber2} />}
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: colors.text }]}>Audio preference</Text>
        <View style={[styles.rowGroup, { backgroundColor: colors.surface, borderColor: colors.border2 }]}>
          {[
            { id: "arabic", label: "Arabic recitation" },
            { id: "both", label: "Arabic with English meaning" },
            { id: "english", label: "English meaning" }
          ].map((item, i) => (
            <TouchableOpacity 
              key={item.id} 
              style={[
                styles.rowItem, 
                i > 0 && { borderTopWidth: 1, borderTopColor: colors.border2 },
                prefs.audio === item.id && { backgroundColor: colors.amberDim }
              ]}
              onPress={() => setPrefs({ ...prefs, audio: item.id })}
            >
              <Text style={[styles.rowText, { color: prefs.audio === item.id ? colors.amber2 : colors.text }]}>{item.label}</Text>
              {prefs.audio === item.id && <Feather name="check" size={18} color={colors.amber2} />}
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: colors.text }]}>Practice intentions</Text>
        <View style={styles.goalsGrid}>
          {goalsOptions.map(g => {
            const isSelected = (prefs.goals || []).includes(g);
            return (
              <TouchableOpacity 
                key={g} 
                style={[
                  styles.goalChip, 
                  { backgroundColor: isSelected ? colors.amber : colors.surface, borderColor: isSelected ? colors.amber : colors.border2 }
                ]}
                onPress={() => toggleGoal(g)}
              >
                <Text style={[styles.goalText, { color: isSelected ? colors.bg2 : colors.text2 }]}>{g}</Text>
              </TouchableOpacity>
            )
          })}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: colors.text }]}>Gentle reminder</Text>
        <TextInput
          value={prefs.reminder || ""}
          onChangeText={(reminder) => setPrefs({ ...prefs, reminder })}
          placeholder="Optional time, for example 7:30 PM"
          placeholderTextColor={colors.text3}
          style={[styles.textInput, { backgroundColor: colors.surface, borderColor: colors.border2, color: colors.text }]}
        />
      </View>

      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: colors.text }]}>School of thought</Text>
        <Text style={[styles.sectionHint, { color: colors.text3 }]}>Used only to frame guidance boundaries. Ask never issues a fatwa.</Text>
        <View style={styles.goalsGrid}>
          {["Not specified", "Hanafi", "Maliki", "Shafi'i", "Hanbali"].map((school) => {
            const value = school === "Not specified" ? "" : school;
            const selected = (prefs.school || "") === value;
            return (
              <TouchableOpacity
                key={school}
                style={[styles.goalChip, { backgroundColor: selected ? colors.greenDim : colors.surface, borderColor: selected ? colors.greenMid : colors.border2 }]}
                onPress={() => setPrefs({ ...prefs, school: value })}
              >
                <Text style={[styles.goalText, { color: selected ? colors.green2 : colors.text2 }]}>{school}</Text>
              </TouchableOpacity>
            );
          })}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: colors.text }]}>Reading display</Text>
        <View style={[styles.rowGroup, { backgroundColor: colors.surface, borderColor: colors.border2 }]}>
          <View style={styles.rowItem}>
            <View style={styles.rowCopy}>
              <Text style={[styles.rowText, { color: colors.text }]}>Show transliteration</Text>
              <Text style={[styles.rowHint, { color: colors.text3 }]}>Arabic remains central either way.</Text>
            </View>
            <Switch
              value={prefs.showTransliteration !== false}
              onValueChange={(showTransliteration) => setPrefs({ ...prefs, showTransliteration })}
              trackColor={{ false: colors.raised, true: colors.greenMid }}
              thumbColor={prefs.showTransliteration !== false ? colors.green2 : colors.text3}
            />
          </View>
          <View style={[styles.rowItem, { borderTopWidth: 1, borderTopColor: colors.border2 }]}>
            <Text style={[styles.rowText, { color: colors.text }]}>Arabic text size</Text>
            <View style={styles.inlineChoices}>
              {["regular", "large", "extra"].map((size) => (
                <TouchableOpacity
                  key={size}
                  style={[styles.sizeChoice, { backgroundColor: prefs.arabicSize === size ? colors.amberDim : colors.bg2, borderColor: prefs.arabicSize === size ? colors.amberMid : colors.border }]}
                  onPress={() => setPrefs({ ...prefs, arabicSize: size })}
                >
                  <Text style={[styles.sizeChoiceText, { color: prefs.arabicSize === size ? colors.amber2 : colors.text3 }]}>{size}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </View>
      </View>

      <TouchableOpacity 
        style={[styles.saveButton, { backgroundColor: colors.amber, opacity: savePreferences.isPending ? 0.7 : 1 }]}
        onPress={handleSave}
        disabled={savePreferences.isPending}
      >
        <Text style={[styles.saveButtonText, { color: colors.bg2 }]}>{savePreferences.isPending ? "Saving..." : "Save preferences"}</Text>
      </TouchableOpacity>

      <View style={[styles.accountSection, { borderTopColor: colors.border }]}>
        <Text style={[styles.accountEmail, { color: colors.text3 }]}>Signed in as {user?.email}</Text>
        <TouchableOpacity 
          style={[styles.signOutButton, { backgroundColor: colors.surface, borderColor: colors.border2 }]}
          onPress={signOut}
        >
          <Text style={[styles.signOutText, { color: colors.destructive }]}>Sign Out</Text>
        </TouchableOpacity>
      </View>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
  },
  content: {
    width: '100%',
    alignSelf: 'center',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  title: {
    fontFamily: 'Inter_700Bold',
    fontSize: 24,
  },
  closeButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
  description: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    marginBottom: 32,
    lineHeight: 20,
  },
  section: {
    marginBottom: 28,
  },
  sectionTitle: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    marginBottom: 12,
  },
  sectionHint: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    lineHeight: 18,
    marginTop: -6,
    marginBottom: 12,
  },
  rowGroup: {
    borderRadius: 12,
    borderWidth: 1,
    overflow: 'hidden',
  },
  rowItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  rowText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 15,
  },
  rowCopy: { flex: 1, paddingRight: 16 },
  rowHint: { fontFamily: 'Inter_400Regular', fontSize: 11, marginTop: 3 },
  inlineChoices: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'flex-end', gap: 6, flex: 1 },
  sizeChoice: { paddingHorizontal: 9, paddingVertical: 7, borderRadius: 8, borderWidth: 1 },
  sizeChoiceText: { fontFamily: 'Inter_500Medium', fontSize: 11, textTransform: 'capitalize' },
  textInput: { minHeight: 50, borderRadius: 12, borderWidth: 1, paddingHorizontal: 16, fontFamily: 'Inter_400Regular', fontSize: 15 },
  goalsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  goalChip: {
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 20,
    borderWidth: 1,
  },
  goalText: {
    fontFamily: 'Inter_500Medium',
    fontSize: 13,
  },
  saveButton: {
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 12,
    marginBottom: 40,
  },
  saveButtonText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 16,
  },
  accountSection: {
    borderTopWidth: 1,
    paddingTop: 32,
    alignItems: 'center',
  },
  accountEmail: {
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
    marginBottom: 16,
  },
  signOutButton: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    borderWidth: 1,
  },
  signOutText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
  }
});

import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ActivityIndicator, Alert } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { getSupabase } from '@/lib/supabase';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function LoginScreen() {
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [err, setErr] = useState('');
  const [loading, setLoading] = useState(false);
  const colors = useColors();
  const insets = useSafeAreaInsets();

  const submit = async () => {
    setErr('');
    const e = email.trim().toLowerCase();
    if (!e || !pass) { setErr("Please enter your email and password."); return; }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e)) { setErr("Please enter a valid email address."); return; }
    if (mode === "signup" && !name.trim()) { setErr("Please enter your name."); return; }
    if (pass.length < 8) { setErr("Password must be at least 8 characters."); return; }
    
    setLoading(true);
    try {
      const client = await getSupabase();
      if (mode === "signup") {
        const { data, error } = await client.auth.signUp({
          email: e, password: pass, options: { data: { display_name: name.trim() } }
        });
        if (error) throw error;
        if (data.user) {
          const { error: profileError } = await client.from("dhikr_profiles").upsert({
            user_id: data.user.id, display_name: name.trim()
          });
          if (profileError && data.session) throw profileError;
        }
        if (!data.session) {
          Alert.alert("Check your email", "Please confirm your account, then sign in.");
          setMode("signin");
          return;
        }
      } else {
        const { data, error } = await client.auth.signInWithPassword({ email: e, password: pass });
        if (error) throw error;
        const displayName = data.user.user_metadata?.display_name || e.split("@")[0];
        const { error: profileError } = await client.from("dhikr_profiles").upsert({
          user_id: data.user.id, display_name: displayName
        });
        if (profileError) throw profileError;
      }
    } catch (error: any) {
      setErr(error.message || "Unable to sign in. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <KeyboardAwareScrollViewCompat
        contentContainerStyle={[styles.scrollContent, { paddingTop: Math.max(insets.top, 40) + 40, paddingBottom: Math.max(insets.bottom, 40) }]}
        keyboardShouldPersistTaps="handled"
        bottomOffset={20}
      >
        <View style={styles.header}>
          <View style={styles.iconPlaceholder}>
            <Text style={[styles.iconText, { color: colors.amber }]}>✦</Text>
          </View>
          <Text style={[styles.arabic, { color: colors.amber }]}>بِسْمِ ٱللَّهِ</Text>
          <Text style={[styles.title, { color: colors.text }]}>The Dhikr Challenge</Text>
          <Text style={[styles.subtitle, { color: colors.text2 }]}>
            {mode === "signup" ? "Create an account to begin your journey" : "Sign in to continue your remembrance"}
          </Text>
        </View>

        <View style={[styles.tabs, { backgroundColor: colors.surface, borderColor: colors.border2 }]}>
          {(['signin', 'signup'] as const).map(t => (
            <TouchableOpacity
              key={t}
              onPress={() => { setMode(t); setErr(""); }}
              style={[
                styles.tabButton,
                mode === t && { backgroundColor: colors.amber }
              ]}
            >
              <Text style={[
                styles.tabText,
                { color: mode === t ? colors.bg2 : colors.text2 }
              ]}>
                {t === 'signin' ? 'Sign In' : 'Create Account'}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.form}>
          {mode === "signup" && (
            <TextInput
              style={[styles.input, { backgroundColor: colors.surface, borderColor: colors.border2, color: colors.text }]}
              placeholder="Your name"
              placeholderTextColor={colors.text3}
              value={name}
              onChangeText={setName}
              autoComplete="name"
              autoCapitalize="words"
            />
          )}
          <TextInput
            style={[styles.input, { backgroundColor: colors.surface, borderColor: colors.border2, color: colors.text }]}
            placeholder="Email"
            placeholderTextColor={colors.text3}
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            autoComplete="email"
          />
          <TextInput
            style={[styles.input, { backgroundColor: colors.surface, borderColor: colors.border2, color: colors.text }]}
            placeholder="Password"
            placeholderTextColor={colors.text3}
            value={pass}
            onChangeText={setPass}
            secureTextEntry
            autoCapitalize="none"
          />

          {err ? (
            <View style={[styles.errorBox, { backgroundColor: colors.roseDim, borderColor: colors.rose }]}>
              <Text style={[styles.errorText, { color: colors.rose }]}>{err}</Text>
            </View>
          ) : null}

          <TouchableOpacity
            style={[styles.submitButton, { backgroundColor: colors.amber, opacity: loading ? 0.7 : 1 }]}
            onPress={submit}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color={colors.bg2} />
            ) : (
              <Text style={[styles.submitText, { color: colors.bg2 }]}>
                {mode === "signup" ? "Begin the Journey" : "Sign In →"}
              </Text>
            )}
          </TouchableOpacity>
        </View>

        <View style={styles.footer}>
          <Text style={[styles.footerText, { color: colors.text3 }]}>
            Your account & practice are securely synced across your devices.
          </Text>
        </View>
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 24,
    justifyContent: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 32,
  },
  iconPlaceholder: {
    width: 64,
    height: 64,
    borderRadius: 32,
    borderWidth: 1.5,
    borderColor: 'rgba(217, 119, 6, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  iconText: {
    fontSize: 24,
  },
  arabic: {
    fontFamily: 'Inter_400Regular', // Using inter as fallback, we don't have Amiri in expo fonts yet
    fontSize: 18,
    marginBottom: 8,
  },
  title: {
    fontFamily: 'Inter_400Regular',
    fontSize: 28,
    marginBottom: 8,
  },
  subtitle: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
  },
  tabs: {
    flexDirection: 'row',
    borderRadius: 12,
    borderWidth: 1,
    padding: 4,
    marginBottom: 24,
  },
  tabButton: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 8,
  },
  tabText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
  },
  form: {
    gap: 12,
  },
  input: {
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    fontFamily: 'Inter_400Regular',
  },
  errorBox: {
    borderWidth: 1,
    borderRadius: 10,
    padding: 12,
  },
  errorText: {
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
  },
  submitButton: {
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 8,
  },
  submitText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 16,
    letterSpacing: 0.5,
  },
  footer: {
    marginTop: 40,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
    textAlign: 'center',
    lineHeight: 18,
  },
});

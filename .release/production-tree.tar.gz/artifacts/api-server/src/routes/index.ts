import { Router, type IRouter } from "express";
import configRouter from "./config";
import healthRouter from "./health";
import supabaseRouter from "./supabase";

const router: IRouter = Router();

router.use(healthRouter);
router.use(configRouter);
router.use(supabaseRouter);

export default router;

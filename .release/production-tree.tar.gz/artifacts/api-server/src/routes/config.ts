import { Router, type IRouter } from "express";

const router: IRouter = Router();

router.get("/config", (req, res) => {
  const url = process.env["SUPABASE_URL"];
  const publishableKey =
    process.env["SUPABASE_PUBLISHABLE_KEY"] ??
    process.env["SUPABASE_ANON_KEY"];

  if (!url || !publishableKey) {
    if (process.env["NODE_ENV"] === "development") {
      const forwardedProtocol = req
        .get("x-forwarded-proto")
        ?.split(",")[0]
        ?.trim();
      const protocol = forwardedProtocol || req.protocol;
      const host = req.get("host");

      res.setHeader("Cache-Control", "no-store");
      res.json({
        url: `${protocol}://${host}/api/supabase`,
        publishableKey: "replit-supabase-connector",
      });
      return;
    }

    res.status(503).json({
      error: "Production authentication is not configured.",
    });
    return;
  }

  res.setHeader("Cache-Control", "public, max-age=300, s-maxage=300");
  res.json({ url, publishableKey });
});

export default router;
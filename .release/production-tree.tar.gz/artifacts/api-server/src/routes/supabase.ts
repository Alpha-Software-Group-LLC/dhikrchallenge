import { ReplitConnectors } from "@replit/connectors-sdk";
import { Router, type IRouter } from "express";

const router: IRouter = Router();
const connectors = new ReplitConnectors();

router.use("/supabase", async (req, res) => {
  try {
    const headers: Record<string, string> = {};
    for (const name of [
      "accept",
      "authorization",
      "content-type",
      "prefer",
      "range",
      "range-unit",
      "x-client-info",
    ]) {
      const value = req.get(name);
      if (value) headers[name] = value;
    }

    const upstream = await connectors.proxy("supabase", req.url, {
      method: req.method,
      headers,
      body:
        req.method === "GET" || req.method === "HEAD" ? undefined : req.body,
    });

    res.status(upstream.status);
    for (const name of [
      "cache-control",
      "content-range",
      "content-type",
      "range-unit",
    ]) {
      const value = upstream.headers.get(name);
      if (value) res.setHeader(name, value);
    }

    const body = Buffer.from(await upstream.arrayBuffer());
    res.send(body);
  } catch (error) {
    req.log.error({ err: error }, "Supabase connector request failed");
    res.status(502).json({ error: "Supabase is temporarily unavailable." });
  }
});

export default router;
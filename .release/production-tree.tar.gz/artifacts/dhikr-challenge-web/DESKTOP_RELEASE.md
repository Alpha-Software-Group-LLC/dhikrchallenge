# Desktop release guide

The web app is the canonical source for the PWA and Tauri desktop shells.

## Local development

- Web/PWA: use the managed Replit web workflow.
- Desktop shell: run `pnpm --filter @workspace/dhikr-challenge-web desktop:dev` on a machine with Tauri's native prerequisites.
- Production desktop bundle: `pnpm --filter @workspace/dhikr-challenge-web desktop:build`.

Desktop builds fetch public Supabase configuration from `https://dhikrchallenge.com/api/config`. Account sessions remain in the platform webview's protected application storage. Human-recorded audio is bundled with the application.

## GitHub releases

Push a tag such as `desktop-v1.0.0`, or run **Desktop release** manually in GitHub Actions. The workflow creates a draft release and attaches platform installers built on native GitHub-hosted runners.

No signing credentials belong in source control. Configure Apple signing/notarization and Tauri updater values as GitHub repository secrets. Windows code-signing can be added to the workflow when a certificate provider is selected.

## Availability links

Edit `src/platforms.jsx` when a real release URL exists, then change only that platform's `available`, `status`, and URL fields. Never mark a platform available before its installer or store listing is public.

iPhone, iPad, Android Phone, and Android Tablet intentionally remain **Coming Soon**.
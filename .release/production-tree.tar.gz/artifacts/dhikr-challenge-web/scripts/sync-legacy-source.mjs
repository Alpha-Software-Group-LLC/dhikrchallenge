import { copyFile, mkdir } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const files = ["data.jsx", "components.jsx", "platforms.jsx", "landing.jsx", "auth.jsx", "app.jsx"];

await mkdir(resolve(root, "public/src"), { recursive: true });
await Promise.all(files.map((file) =>
  copyFile(resolve(root, "src", file), resolve(root, "public/src", file))
));
fn main() {
    dhikr_challenge_lib::run();
}